/***************************************************************
  MantisChessDraw.cpp : MantisChess ��ͼ����

  ��Ȩ����(C)  �³���

  ��һ������������������������������������������GNUͨ�ù���
  ����֤�������޸ĺ����·�����һ���򡣻���������֤�ĵڶ��棬����
  (�������ѡ��)���κθ��µİ汾��

  ������һ�����Ŀ����ϣ�������ã���û���κε���������û���ʺ���
  ��Ŀ�ĵ������ĵ���������ϸ����������GNUͨ�ù�������֤��
  
  ��Ӧ���Ѿ��ͳ���һ���յ�һ��GNUͨ�ù�������֤�ĸ�����
  �����û�У�д�Ÿ���

  The Free Software Foundation��Inc����675 Mass Ave�� Cambridge��
  MAO2139��USA

  �������ʹ�ñ�����ʱ��ʲô������飬�����µ�ַ��������ȡ����
  ϵ��

              http://thecct.51.net

  ��Email����

              stove@eyou.com
              thecct@163.com

------------------------------------------------------------------
MantisChessDraw.cpp : MantisChess drawing functions

  Copyright (C)  Chen Chengtao, China
  
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
  
  If you have any question about this software please visit my hompage:

              http://thecct.51.net

  or E_mail to:

              stove@eyou.com
              thecct@163.com

***************************************************************/
/***************************************************************
  �޸��ߣ� ��Ԫһ
  �޸����ݣ�
         ���Ӷ�Linux��֧�֡�
         ��ȫ�ֱ����������޸�ΪLinux֧�ֵ����ͣ���SDL������
         Windows GDI��ͼ��
  
  �޸����ڣ� 2004-08-18
  
  mail�� zyylovedeer@hotmail.com
***************************************************************/

#include "SDL.h"
#include "stdlib.h"

#include "mantisChessDef.h"
#include "mantisChessStd.h"
#include "mantisChessDraw.h"
#include "mantisChessThink.h"

//ȫ�ֱ���
SDL_Surface	*g_screen;    //��ĻSurface
SDL_Surface	*g_buffer;   //������Surface
SDL_Surface  *g_board;   //�洢����λͼ

//��Ϸ����
static  POINT g_pointChessman[32];	//��������
static  int g_iChessmanMap[11][12];	//��λ״̬
static  int g_iSide;				//�ֵ��ķ���
static 	POINT g_pointBoxFrom;		//���һ����ԭʼλ��
static 	POINT g_pointBoxTo;			//���һ����Ŀ��λ��
static 	int g_iChessmanSelect;		//ѡ�������
static 	int g_iComputerSide;		//���Ե���ɫ
static  bool g_bEndGame;			//��Ϸ������־
static  bool g_bCanMove[11][12];	

static 	SDL_Surface* g_hIconChessman[14];   //���ӵ�λͼ
static 	SDL_Surface* g_hIconBox;		    //ָʾ���һ���߷��Ŀ�
static 	SDL_Surface* g_hIconSelect;		    //ָʾѡ�����ӵĿ�
static 	SDL_Surface* g_hIconCanMove;	    //ָʾ�ɵ����λ��
static 	SDL_Surface* g_hIconAttack;		    //ָʾ������������
static  SDL_Surface* g_hIconMantis;         //ָʾ����ͼ��
static  SDL_Surface* g_hIconTips;           //ָʾ�û�������Ϣ
static  SDL_Surface* g_hIconOver;           //ָʾ��Ϸ����

static	struct	MOVEHISTORY	g_MoveHistory;

//��������
bool Go( int man, POINT targetpoint);
void renderScene();

void reset()
{
    int i,j;

	g_pointChessman[0].x=5;g_pointChessman[0].y=10;	//˧
	g_pointChessman[1].x=4;g_pointChessman[1].y=10;	//ʿ
	g_pointChessman[2].x=6;g_pointChessman[2].y=10;	
	g_pointChessman[3].x=3;g_pointChessman[3].y=10;	//��
	g_pointChessman[4].x=7;g_pointChessman[4].y=10;
	g_pointChessman[5].x=2;g_pointChessman[5].y=10;	//��
	g_pointChessman[6].x=8;g_pointChessman[6].y=10;
	g_pointChessman[7].x=1;g_pointChessman[7].y=10;	//��
	g_pointChessman[8].x=9;g_pointChessman[8].y=10;
	g_pointChessman[9].x=2;g_pointChessman[9].y=8;	//��
	g_pointChessman[10].x=8;g_pointChessman[10].y=8;
	g_pointChessman[11].x=1;g_pointChessman[11].y=7;//��
	g_pointChessman[12].x=3;g_pointChessman[12].y=7;
	g_pointChessman[13].x=5;g_pointChessman[13].y=7;
	g_pointChessman[14].x=7;g_pointChessman[14].y=7;
	g_pointChessman[15].x=9;g_pointChessman[15].y=7;
	g_pointChessman[16].x=5;g_pointChessman[16].y=1;//��
	g_pointChessman[17].x=4;g_pointChessman[17].y=1;//ʿ
	g_pointChessman[18].x=6;g_pointChessman[18].y=1;
	g_pointChessman[19].x=3;g_pointChessman[19].y=1;//��
	g_pointChessman[20].x=7;g_pointChessman[20].y=1;
	g_pointChessman[21].x=2;g_pointChessman[21].y=1;//��
	g_pointChessman[22].x=8;g_pointChessman[22].y=1;
	g_pointChessman[23].x=1;g_pointChessman[23].y=1;//��
	g_pointChessman[24].x=9;g_pointChessman[24].y=1;
	g_pointChessman[25].x=2;g_pointChessman[25].y=3;//��
	g_pointChessman[26].x=8;g_pointChessman[26].y=3;
	g_pointChessman[27].x=1;g_pointChessman[27].y=4;//��
	g_pointChessman[28].x=3;g_pointChessman[28].y=4;
	g_pointChessman[29].x=5;g_pointChessman[29].y=4;
	g_pointChessman[30].x=7;g_pointChessman[30].y=4;
	g_pointChessman[31].x=9;g_pointChessman[31].y=4;

	g_iSide=RED;

	FixManMap(g_iChessmanMap,g_pointChessman,g_iSide);
	g_pointBoxFrom.x=0;
	g_pointBoxFrom.y=0;
	g_pointBoxTo.x=0;
	g_pointBoxTo.y=0;
	g_iChessmanSelect=32;
	g_iComputerSide=1;
	g_bEndGame=false;
	g_MoveHistory.count=0;

	for(i=0;i<11;i++)
	for(j=0;j<12;j++)
	{
		g_bCanMove[i][j]=false;
	}
}

void initSurface()
{
    g_board = SDL_CreateRGBSurface( SDL_HWSURFACE, 
                  XBW, 
				  YBW, 
				  g_screen->format->BitsPerPixel,
				  g_screen->format->Rmask,
				  g_screen->format->Gmask,
				  g_screen->format->Bmask,
				  g_screen->format->Amask);
    g_buffer = SDL_CreateRGBSurface( SDL_HWSURFACE, 
                  XBW, 
				  YBW, 
				  g_screen->format->BitsPerPixel,
				  g_screen->format->Rmask,
				  g_screen->format->Gmask,
				  g_screen->format->Bmask,
				  g_screen->format->Amask);   
}

void onCreate()
{
    Uint32 colorKey = SDL_MapRGB( g_screen->format, 0, 0, 0 );
    
    CC_Color bgColor = { 180, 224, 160 };
    
    initSurface();
    
    makeBoard( g_board, bgColor );

    reset();
    
    g_hIconChessman[RED_K] = SDL_LoadBMP( "pic/red_k.bmp" );
    g_hIconChessman[RED_K] = SDL_ConvertSurface( g_hIconChessman[RED_K], g_screen->format, SDL_HWSURFACE );
    SDL_SetColorKey( g_hIconChessman[RED_K], SDL_SRCCOLORKEY, colorKey );
    g_hIconChessman[RED_S] = SDL_LoadBMP( "pic/red_s.bmp" );
    g_hIconChessman[RED_S] = SDL_ConvertSurface( g_hIconChessman[RED_S], g_screen->format, SDL_HWSURFACE );
	SDL_SetColorKey( g_hIconChessman[RED_S], SDL_SRCCOLORKEY, colorKey );
    g_hIconChessman[RED_X] = SDL_LoadBMP( "pic/red_x.bmp" );
    g_hIconChessman[RED_X] = SDL_ConvertSurface( g_hIconChessman[RED_X], g_screen->format, SDL_HWSURFACE );
    SDL_SetColorKey( g_hIconChessman[RED_X], SDL_SRCCOLORKEY, colorKey );
	g_hIconChessman[RED_M] = SDL_LoadBMP( "pic/red_m.bmp" );
    g_hIconChessman[RED_M] = SDL_ConvertSurface( g_hIconChessman[RED_M], g_screen->format, SDL_HWSURFACE );
    SDL_SetColorKey( g_hIconChessman[RED_M], SDL_SRCCOLORKEY, colorKey );
	g_hIconChessman[RED_J] = SDL_LoadBMP( "pic/red_j.bmp" );
    g_hIconChessman[RED_J] = SDL_ConvertSurface( g_hIconChessman[RED_J], g_screen->format, SDL_HWSURFACE );
    SDL_SetColorKey( g_hIconChessman[RED_J], SDL_SRCCOLORKEY, colorKey );
	g_hIconChessman[RED_P] = SDL_LoadBMP( "pic/red_p.bmp" );
    g_hIconChessman[RED_P] = SDL_ConvertSurface( g_hIconChessman[RED_P], g_screen->format, SDL_HWSURFACE );
    SDL_SetColorKey( g_hIconChessman[RED_P], SDL_SRCCOLORKEY, colorKey );
	g_hIconChessman[RED_B] = SDL_LoadBMP( "pic/red_b.bmp" );
    g_hIconChessman[RED_B] = SDL_ConvertSurface( g_hIconChessman[RED_B], g_screen->format, SDL_HWSURFACE );
    SDL_SetColorKey( g_hIconChessman[RED_B], SDL_SRCCOLORKEY, colorKey );
    
    g_hIconOver = SDL_LoadBMP( "pic/over.bmp" );
    g_hIconOver = SDL_ConvertSurface( g_hIconOver, g_screen->format, SDL_HWSURFACE );
    SDL_SetColorKey( g_hIconOver, SDL_SRCCOLORKEY, colorKey );
    g_hIconTips = SDL_LoadBMP( "pic/tips.bmp" );
    g_hIconTips = SDL_ConvertSurface( g_hIconTips, g_screen->format, SDL_HWSURFACE );
    
    colorKey = SDL_MapRGB( g_screen->format, 255, 0, 0 );
	
    g_hIconChessman[BLACK_K] = SDL_LoadBMP( "pic/black_k.bmp" );
    g_hIconChessman[BLACK_K] = SDL_ConvertSurface( g_hIconChessman[BLACK_K], g_screen->format, SDL_HWSURFACE );
    SDL_SetColorKey( g_hIconChessman[BLACK_K], SDL_SRCCOLORKEY, colorKey );
	g_hIconChessman[BLACK_S] = SDL_LoadBMP( "pic/black_s.bmp" );
    g_hIconChessman[BLACK_S] = SDL_ConvertSurface( g_hIconChessman[BLACK_S], g_screen->format, SDL_HWSURFACE );
    SDL_SetColorKey( g_hIconChessman[BLACK_S], SDL_SRCCOLORKEY, colorKey );
	g_hIconChessman[BLACK_X] = SDL_LoadBMP( "pic/black_x.bmp" );
    g_hIconChessman[BLACK_X] = SDL_ConvertSurface( g_hIconChessman[BLACK_X], g_screen->format, SDL_HWSURFACE );
    SDL_SetColorKey( g_hIconChessman[BLACK_X], SDL_SRCCOLORKEY, colorKey );
	g_hIconChessman[BLACK_M] = SDL_LoadBMP( "pic/black_m.bmp" );
    g_hIconChessman[BLACK_M] = SDL_ConvertSurface( g_hIconChessman[BLACK_M], g_screen->format, SDL_HWSURFACE );
    SDL_SetColorKey( g_hIconChessman[BLACK_M], SDL_SRCCOLORKEY, colorKey );
	g_hIconChessman[BLACK_J] = SDL_LoadBMP( "pic/black_j.bmp" );
    g_hIconChessman[BLACK_J] = SDL_ConvertSurface( g_hIconChessman[BLACK_J], g_screen->format, SDL_HWSURFACE );
    SDL_SetColorKey( g_hIconChessman[BLACK_J], SDL_SRCCOLORKEY, colorKey );
	g_hIconChessman[BLACK_P] = SDL_LoadBMP( "pic/black_p.bmp" );
    g_hIconChessman[BLACK_P] = SDL_ConvertSurface( g_hIconChessman[BLACK_P], g_screen->format, SDL_HWSURFACE );
    SDL_SetColorKey( g_hIconChessman[BLACK_P], SDL_SRCCOLORKEY, colorKey );
	g_hIconChessman[BLACK_B] = SDL_LoadBMP( "pic/black_b.bmp" );
    g_hIconChessman[BLACK_B] = SDL_ConvertSurface( g_hIconChessman[BLACK_B], g_screen->format, SDL_HWSURFACE );
    SDL_SetColorKey( g_hIconChessman[BLACK_B], SDL_SRCCOLORKEY, colorKey );
    
    colorKey = SDL_MapRGB( g_screen->format, 0, 255, 0 );
    g_hIconBox = SDL_LoadBMP( "pic/box.bmp" );
    g_hIconBox = SDL_ConvertSurface( g_hIconBox, g_screen->format, SDL_HWSURFACE );
    SDL_SetColorKey( g_hIconBox, SDL_SRCCOLORKEY, colorKey );
	g_hIconSelect = SDL_LoadBMP( "pic/select.bmp" );
    g_hIconSelect = SDL_ConvertSurface( g_hIconSelect, g_screen->format, SDL_HWSURFACE );
    SDL_SetColorKey( g_hIconSelect, SDL_SRCCOLORKEY, colorKey );
	g_hIconCanMove = SDL_LoadBMP( "pic/canmove.bmp" );
    g_hIconCanMove = SDL_ConvertSurface( g_hIconCanMove, g_screen->format, SDL_HWSURFACE );
    SDL_SetColorKey( g_hIconCanMove, SDL_SRCCOLORKEY, colorKey );
	g_hIconAttack = SDL_LoadBMP( "pic/attack.bmp" );
    g_hIconAttack = SDL_ConvertSurface( g_hIconAttack, g_screen->format, SDL_HWSURFACE );
    SDL_SetColorKey( g_hIconAttack, SDL_SRCCOLORKEY, colorKey );
    
    SDL_Rect rect;
    rect.x = XBW-170;
    rect.y = 50;
    rect.w = g_hIconTips->w;
    rect.h = g_hIconTips->h;
    
    SDL_BlitSurface( g_hIconTips, NULL, g_board, &rect );
}

void releaseResource()
{
    for( int i = 0; i < 14; i++ )
    {
        SDL_FreeSurface( g_hIconChessman[i] );
    }
    
    SDL_FreeSurface( g_hIconBox );
    SDL_FreeSurface( g_hIconMantis );
    SDL_FreeSurface( g_hIconSelect );
    SDL_FreeSurface( g_hIconCanMove );
    SDL_FreeSurface( g_hIconAttack );
    
    SDL_FreeSurface( g_hIconOver );
    SDL_FreeSurface( g_hIconTips );
    
    SDL_FreeSurface( g_board );
    SDL_FreeSurface( g_buffer );
}

void onMouseMove()
{    
}

bool FaceToPoint(POINT &point)
{
	if((point.x)%BWA<SW||(point.x)%BWA>BWA-SW)return false;
	if((point.y)%BWA<SW||(point.y)%BWA>BWA-SW)return false;
	POINT p;
	p.x=(point.x)/BWA+1;
	p.y=(point.y)/BWA+1;
	if(p.x<1||p.x>9||p.y<1||p.y>10)return false;
	point=p;
	return true;
}

void Think()
{
	int i,j;
	POINT tmanposition[32];
	int  tside;
	int tmap[11][12];
	for(i=0;i<32;i++)
	{
		tmanposition[i]=g_pointChessman[i];
	}
	tside=g_iSide;
	for(i=0;i<11;i++)
	for(j=0;j<12;j++)
	{
		tmap[i][j]=g_iChessmanMap[i][j];
	}
	int resultman=32;
	POINT resultpoint={0,0};
	bool flag=Think(tmap,tmanposition,tside,resultman,resultpoint);
	if(flag)
	{
		Go( resultman,resultpoint);
	}
	else
	{
		g_bEndGame=true;
	}

}

bool Go( int man, POINT targetpoint)
{
	int i,j;

	if(g_bEndGame)
    {
        return false;
    }
    
	if(g_MoveHistory.count>=MAXMOVE)
    {
        g_MoveHistory.count=0;
    }

	if(!CanGo(g_iChessmanMap,man,g_pointChessman[man],targetpoint))
    {
        return false;
    }
	
	g_MoveHistory.betaken[g_MoveHistory.count] = g_iChessmanMap[targetpoint.x][targetpoint.y];
	g_MoveHistory.man[g_MoveHistory.count] = man;
	g_MoveHistory.from[g_MoveHistory.count] = g_pointChessman[man];
	g_MoveHistory.to[g_MoveHistory.count] = targetpoint;
	g_MoveHistory.count++;

	if(g_iChessmanMap[targetpoint.x][targetpoint.y] != 32)
	{
		g_pointChessman[g_iChessmanMap[targetpoint.x][targetpoint.y]].x=0;
	}

	POINT from,to;

	from=g_pointBoxFrom;
	to=g_pointBoxTo;
	g_pointBoxFrom=g_pointChessman[man];
	g_pointBoxTo=targetpoint;

	POINT oldselect;
	oldselect=g_pointChessman[man];
	g_pointChessman[man]=targetpoint;
	FixManMap(g_iChessmanMap,g_pointChessman,g_iSide);

	g_iChessmanSelect=32;
	g_iSide=!g_iSide;

	
	for(i=0;i<11;i++)
	for(j=0;j<12;j++)
	{
		POINT pt;
		pt.x=i;
		pt.y=j;
		if(CanGo(g_iChessmanMap,man,g_pointChessman[man],pt))
		{
			if(!g_bCanMove[i][j])
			{
				g_bCanMove[i][j]=true;
			}
		}
		else
		{
			if(g_bCanMove[i][j])
			{
				g_bCanMove[i][j]=false;
			}
		}
	}

    renderScene();

	if(g_pointChessman[FistOfSide[g_iSide]].x==0)
	{
		g_bEndGame=true;
		return true;
	}
	if(g_iComputerSide==g_iSide&&!g_bEndGame)
	{
		//SetCursor(g_hCurThinking);
		Think();
		//SetCursor(g_hCurCantGo);
	}
	return true;
}

void onLButtonDown( Uint16 x, Uint16 y )
{
    int i,j;
    POINT point = {x,y};

	if(g_bEndGame)
	{
		
	}
	else if(FaceToPoint(point))
	{
		if(SideOfMan[g_iChessmanMap[point.x][point.y]]==!g_iComputerSide)
		{
			POINT p;
			bool flag=false;
			if(g_iChessmanSelect!=32)
			{
				p=g_pointChessman[g_iChessmanSelect];
				flag=true;
			}
			g_iChessmanSelect=g_iChessmanMap[point.x][point.y];

			for(i=0;i<11;i++)
			for(j=0;j<12;j++)
			{
				POINT pt;
				pt.x=i;
				pt.y=j;
				if(CanGo(g_iChessmanMap,g_iChessmanSelect,g_pointChessman[g_iChessmanSelect],pt))
				{
					if(!g_bCanMove[i][j])
					{
						g_bCanMove[i][j]=true;
					}
				}
				else
				{
					if(g_bCanMove[i][j])
					{
						g_bCanMove[i][j]=false;
					}
				}
			}
		}
		else if(g_iChessmanSelect!=32)
		{
			Go( g_iChessmanSelect,point);
		}
	}
}

void drawIcon( int x, int y, SDL_Surface* image )
{
    SDL_Rect rect;
    
    rect.x = x;
    rect.y = y;
    rect.w = image->w;
    rect.h = image->h;
    
    SDL_BlitSurface( image, NULL, g_buffer, &rect );
}
/******************************************************************
ShowRect:		�ػ� prect ָ�������

����:
hdc:			�豸���������
prect:			�ػ������ָ��

����ֵ:			��
******************************************************************/
void showRect()
{
    int left = 0, top = 0, right = 9, bottom = 10;

	for(int i = left; i <= right; i++ )
	{
        for(int j = top; j <= bottom; j++ )
	    {
		    if(g_iChessmanMap[i+1][j+1]!=32)
            {
			    drawIcon( i*BWA+SW,j*BWA+SW, g_hIconChessman[ManToIcon[g_iChessmanMap[i+1][j+1]]]);
            }
            
		    if(g_pointBoxFrom.x==i+1&&g_pointBoxFrom.y==j+1||g_pointBoxTo.x==i+1&&g_pointBoxTo.y==j+1)
			{
                drawIcon( i*BWA+SW,j*BWA+SW, g_hIconBox);
		    }
            
            if(g_iChessmanSelect!=32)
		    {
			    if(g_pointChessman[g_iChessmanSelect].x==i+1&&g_pointChessman[g_iChessmanSelect].y==j+1)
                {
				    drawIcon( i*BWA+SW, j*BWA+SW, g_hIconSelect);			
                }
		    }
		    
            if(g_bCanMove[i+1][j+1])
		    {
			    if(g_iChessmanMap[i+1][j+1]==32)
                {
				    drawIcon( i*BWA+SW, j*BWA+SW, g_hIconCanMove);
                }
			    else
                {
				    drawIcon( i*BWA+SW, j*BWA+SW, g_hIconAttack);
                }
		    }
	    }
    }
}

void renderScene()
{
    SDL_BlitSurface( g_board, NULL, g_buffer, NULL );
    
    showRect();
    
    if( g_bEndGame == true )
    {
        drawIcon( 100, 100, g_hIconOver );
    }
    
    SDL_BlitSurface( g_buffer, NULL, g_screen, NULL );
    SDL_UpdateRect( g_screen, 0, 0, 0, 0 );
}

void onBack()
{
	int i,j;
	if(g_MoveHistory.count<2 )return;
	if(g_bEndGame)
	{
		return;
	}
	for( i=g_MoveHistory.count-1;i>=g_MoveHistory.count-2;i--)
	{
		g_pointChessman[g_MoveHistory.man[i]]=g_MoveHistory.from[i];
		g_iChessmanSelect=g_MoveHistory.man[i];
		g_iChessmanMap[g_MoveHistory.from[i].x][g_MoveHistory.from[i].y]=g_MoveHistory.man[i];
		g_pointBoxFrom=g_MoveHistory.from[i];
		if(g_MoveHistory.betaken[i]!=32)
		{
			g_pointChessman[g_MoveHistory.betaken[i]]=g_MoveHistory.to[i];
		}
		g_iChessmanMap[g_MoveHistory.to[i].x][g_MoveHistory.to[i].y]=g_MoveHistory.betaken[i];
		g_pointBoxTo=g_MoveHistory.to[i];
	}
	
	g_MoveHistory.count-=2;
	g_bEndGame=false;
	
	for(i=0;i<11;i++)
	for(j=0;j<12;j++)
	{
		g_bCanMove[i][j]=false;
	}
}

void KeyPressed(SDL_keysym * keysym)
{
    switch(keysym -> sym)
    {
        case SDLK_b:
            reset();
			g_iComputerSide=RED;
			Think();  
            break;
        case SDLK_r:
            reset();
			g_iComputerSide=BLACK;
            break;
        case SDLK_p:
            onBack();
            break;
        case SDLK_ESCAPE:
            releaseResource();
            SDL_Quit();
            exit(0);
            break;
    }
}                    
            
int main (int argc, char **argv)
{
    SDL_Init( SDL_INIT_VIDEO );             
	
    SDL_WM_SetCaption( "�й�����", NULL );
    
    
    
    g_hIconMantis = SDL_LoadBMP( "pic/mantis.bmp" );
    
    SDL_WM_SetIcon( g_hIconMantis, NULL );
    
    g_screen = SDL_SetVideoMode( XBW, YBW, 32, SDL_SWSURFACE);
    
    onCreate(); 

    bool done = false;                                     
    SDL_Event event;

    while(! done)                                          
    {
        while( SDL_PollEvent(& event) )                   
        {
            switch ( event.type )                          
            {
                case SDL_QUIT:
                    releaseResource();                                         
                    done = true;                                        
                    break;
                case SDL_MOUSEMOTION:
                    onMouseMove();
                    break;
                case SDL_MOUSEBUTTONDOWN:
                    if( event.button.button == SDL_BUTTON_LEFT )
                    {
                        onLButtonDown( event.button.x, event.button.y );
                    }
                    break;
                case SDL_KEYDOWN :                                      // if the user has pressed a key
                    KeyPressed( & event.key.keysym );                  // callback for handling keystrokes, arg is key pressed
                    break;
                default:                                    
                    break;                                  
            } // switch
        } // while( SDL_ ...
        
        renderScene();                                     
    }
    
    SDL_Quit();
    return 0;
}

        
