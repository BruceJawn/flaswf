/***************************************************************
  MantisChessThink.cpp : MantisChess �˹����ܲ���

  ��Ȩ����(C)  �³���

  ��һ������������������������������������������GNUͨ�ù���
  ����֤�������޸ĺ����·�����һ���򡣻���������֤�ĵڶ��棬����
  (�������ѡ��)���κθ��µİ汾��

  ������һ�����Ŀ����ϣ�������ã���û���κε���������û���ʺ���
  ��Ŀ�ĵ������ĵ���������ϸ����������GNUͨ�ù�������֤��
  
  ��Ӧ���Ѿ��ͳ���һ���յ�һ��GNUͨ�ù�������֤�ĸ�����
  �����û�У�д�Ÿ���

  The Free Software Foundation��Inc����675 Mass Ave�� Cambridge��
  MAO2139��USA

  �������ʹ�ñ�����ʱ��ʲô������飬�����µ�ַ��������ȡ����
  ϵ��

              http://thecct.51.net

  ��Email����

              stove@eyou.com
              thecct@163.com

------------------------------------------------------------------
  MantisChessThink.cpp : MantisChess AI functions

  Copyright (C)  Chen Chengtao, China
  
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
  
  If you have any question about this software please visit my hompage:

              http://thecct.51.net

  or E_mail to:

              stove@eyou.com
              thecct@163.com

******************************************************************/
/***************************************************************
  �޸��ߣ� ��Ԫһ
  �޸����ݣ�
         ���Ӷ�Linux��֧�֡�
  
  �޸����ڣ� 2004-08-18
  
  mail�� zyylovedeer@hotmail.com
***************************************************************/
#include <string.h>

#include "mantisChessDef.h"
#include "mantisChessThink.h"
//-------------���漸����Ե�������ģ��---------------------------
#define S_WIDTH 8
#define S_DEPTH 6

//                ��  ʿ  ��  ��  ��  ��   ��
const int base[7]=	{300,400,300,600, 1000,600,300};	//ƽ����ֵ
const int range[7]=	{0  ,  0,  0, 20,  10,  0, 50};	    //��ֵ�ı䶯��Χ

const int contactpercent1=20;	//���ص����ӳ̶�
const int contactpercent2=25;	//���������ӳ̶�

/******************************************************************
����������Ϊƽ����ֵ200,�䶯��Χ��13%Ӧ��base[3]=200��range[3]=13
*******************************************************************/
//-----------------------------------------------------------------

const int BV1[7]=//������ֵ
{  
	base[0]-base[0]*range[0]/100,
	base[1]-base[1]*range[1]/100,
	base[3]-base[2]*range[2]/100,
	base[3]-base[3]*range[3]/100,
	base[4]-base[4]*range[4]/100,
	base[5]-base[5]*range[5]/100,
	base[6]-base[6]*range[6]/100
};
const int BV2[7]=//��Ծ��
{ 
	2*base[0]*range[0]/100/4,
	2*base[1]*range[1]/100/4,
	2*base[2]*range[2]/100/4,
	2*base[3]*range[3]/100/8,
	2*base[4]*range[4]/100/17,
	2*base[5]*range[5]/100/17,
	0,
};

const int BV3[5]=//���ڲ�ͬλ�õļ�ֵ����
{
	0*2*base[6]*range[6]/100/4,
	1*2*base[6]*range[6]/100/4,
	2*2*base[6]*range[6]/100/4,
	3*2*base[6]*range[6]/100/4,
	4*2*base[6]*range[6]/100/4,
};

#define NORED(i,j) (SideOfMan[tmap[i][j]]!=0)
#define NOBLACK(i,j) (SideOfMan[tmap[i][j]]!=1)
#define NOMAN(i,j) (tmap[i][j]==32)


//�����ڲ�ͬλ�õļ�ֵ������Խ���ֵԽ��
const int ManBPlus[2][12][11]=
{
	{
		{  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0},
		{  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0},
		{  0,  1,  2,  3,  4,  4,  4,  3,  2,  1,  0},
		{  0,  1,  2,  3,  4,  4,  4,  3,  2,  1,  0},
		{  0,  1,  2,  3,  3,  3,  3,  3,  2,  1,  0},
		{  0,  1,  1,  1,  1,  1,  1,  1,  1,  1,  0},
		{  0,  0,  0,  1,  0,  0,  0,  1,  0,  0,  0},
		{  0,  0,  0,  0,  0,  2,  0,  0,  0,  0,  0},
		{  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0},
		{  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0},
		{  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0},
		{  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0}
	},
	{
		{  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0},
		{  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0},
		{  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0},
		{  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0},
		{  0,  0,  0,  0,  0,  2,  0,  0,  0,  0,  0},
		{  0,  0,  0,  1,  0,  0,  0,  1,  0,  0,  0},
		{  0,  1,  1,  1,  1,  1,  1,  1,  1,  1,  0},
		{  0,  1,  2,  3,  3,  3,  3,  3,  2,  1,  0},
		{  0,  1,  2,  3,  4,  4,  4,  3,  2,  1,  0},
		{  0,  1,  2,  3,  4,  4,  4,  3,  2,  1,  0},
		{  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0},
		{  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0}
	}
};

//-------------------------------------------
static void ContactV(int tmap[11][12],POINT tmanposition[32],int &tside,int activity[32],int contact[32][32]);


/******************************************************************
Mantis_QuickSort:���߷��б����п�������

����:
A��				�ؼ�ֵ
chessman:		������������б�
targetpoint:	�������Ŀ����б�
low,high:		QuickSort������

����ֵ:			��
******************************************************************/
void Mantis_QuickSort(int A[],int chessman[],POINT targetpoint[],int low,int high)
{
	int pivot;
	int pivot_man;
	POINT pivot_point;
	int scanUp,scanDown;
	int mid,k;
	POINT point;
	if(high-low<=0)
	{
		return;
	}
	else
	{
		if(high-low==1)
		{
			if(A[high]>A[low])
			{
				k=A[high];
				A[high]=A[low];
				A[low]=k;
				k=chessman[high];
				chessman[high]=chessman[low];
				chessman[low]=k;
				point=targetpoint[high];
				targetpoint[high]=targetpoint[low];
				targetpoint[low]=point;
				return;
			}
		}
	}
	mid=(low +high)/2;
	pivot=A[mid];
	pivot_man=chessman[mid];
	pivot_point=targetpoint[mid];
	k=A[mid];
	A[mid]=A[low];
	A[low]=k;
	k=chessman[mid];
	chessman[mid]=chessman[low];
	chessman[low]=k;
	point=targetpoint[mid];
	targetpoint[mid]=targetpoint[low];
	targetpoint[low]=point;
	scanUp =low+1;
	scanDown = high;
	do{
		while(scanUp<=scanDown && A[scanUp]>=pivot)
			scanUp++;
		while(pivot>A[scanDown])
			scanDown--;
		if(scanUp<scanDown)
		{
			k=A[scanUp];
			A[scanUp]=A[scanDown];
			A[scanDown]=k;	
			k=chessman[scanUp];
			chessman[scanUp]=chessman[scanDown];
			chessman[scanDown]=k;
			point=targetpoint[scanUp];
			targetpoint[scanUp]=targetpoint[scanDown];
			targetpoint[scanDown]=point;
		}
	}while(scanUp<scanDown);
	A[low]=A[scanDown];
	A[scanDown]=pivot;
	chessman[low]=chessman[scanDown];
	chessman[scanDown]=pivot_man;
	targetpoint[low]=targetpoint[scanDown];
	targetpoint[scanDown]=pivot_point;

	if(low<scanDown-1)
		Mantis_QuickSort(A,chessman,targetpoint,low,scanDown-1);
	if(scanDown+1<high)
		Mantis_QuickSort(A,chessman,targetpoint,scanDown+1,high);
}

/******************************************************************
Value:			��ֵ����

����:
tmap:			����λ״̬
tmanposition:	32���ӵ�����
tside:			�ֵ���һ����

����ֵ:			����ļ�ֵ
******************************************************************/
int Value(int tmap[11][12],POINT tmanposition[32],int &tside)
{
	static int k;
	static int ManExtValue[32];
	static int ManBaseValue[32];
	static int ManContact[32][32];
	static int BeAteCount[32];
	static bool OwnSee[32];
	memset(ManContact, 0, sizeof(int)*32*32);
	memset(ManBaseValue,0,sizeof(int)*32);
	memset(ManExtValue,0,sizeof(int)*32);
	memset(BeAteCount,0,sizeof(int)*32);
	memset(OwnSee,0,sizeof(int)*32);
	int maxvalue=0;
	int i,j;
	ContactV(tmap,tmanposition,tside,ManBaseValue,ManContact);
//��������			
	for(i=FistOfSide[tside];i<=LastOfSide[tside];i++)
	{
		if(ManContact[i][FistOfSide[!tside]])
		{
			maxvalue=9700;
			return maxvalue;
		}
	}
	for(i=0;i<32;i++)
	{
		k=ManToType7[i];
		ManBaseValue[i]=BV1[k]+ManBaseValue[i]*BV2[k];
		switch(k)
		{	
		case 6:	ManBaseValue[i]+=BV3[ ManBPlus[SideOfMan[i]][tmanposition[i].y][tmanposition[i].x] ];
			break;
		}
	}
	for(i=0;i<32;i++)
	{
		for(j=0;j<32;j++)
		{
			if(ManContact[i][j])
			{
				if(SideOfMan[i]==SideOfMan[j])
				{
					BeAteCount[j]++;
					if(!OwnSee[j])
					{
						ManExtValue[i]+=ManBaseValue[j]*contactpercent1/100;//����
						OwnSee[j]=true;
					}
				}
				else
				{
					ManExtValue[i]+=ManBaseValue[j]*contactpercent2/100;//�Է�
					BeAteCount[j]--;
				}
			}
		}
	}
	for(i=FistOfSide[tside];i<=LastOfSide[tside];i++)
	{
		if(tmanposition[i].x)maxvalue+=ManBaseValue[i]+ManExtValue[i];			
	}
	static bool flag;
	flag=false;k=32;		
	for(i=FistOfSide[!tside];i<=LastOfSide[!tside];i++)
	{
		if(tmanposition[i].x)maxvalue-=ManBaseValue[i]+ManExtValue[i];			
//�Է�����
		if(ManContact[i][FistOfSide[tside]])
		{
			flag=true;
			k=i;
			break;
		}
	}
	if(flag&&BeAteCount[k]>=0)//����,�����������Ӳ��ܱ��Ե�
	{
		j=0;
		for(i=FistOfSide[tside];i<=LastOfSide[tside];i++)
		{
			if(BeAteCount[i]<0 && ManBaseValue[i]>j)
				j=ManBaseValue[i];
		}
		maxvalue -=j;
	}
	else
	{
		j=0;
		for(i=FistOfSide[!tside];i<=LastOfSide[!tside];i++)
		{
			if(BeAteCount[i]<0 && ManBaseValue[i]>j)
				j=ManBaseValue[i];
		}
		maxvalue +=j;
	}
	return maxvalue;
}

/******************************************************************
EnumList:		�г������߷�

����:
tmap:			����λ״̬
tmanposition:	32���ӵ�����
tside:			�ֵ���һ����
chessman:		ָ�������б���ָ�루��Ž����
move:			ָ���������ߵ�λ�õ�ָ�룬��chessmanһ������߷��б�
				����Ž����
count:			�߷�����������Ž����

����ֵ:			�����ࡱ����true,���򷵻�false
******************************************************************/
bool EnumList(int tmap[11][12],POINT tmanposition[32],int &tside,int *chessman,POINT *move,int &count)
{
	#define ADD(man,tx,ty) {chessman[count]=man;move[count].x=tx;move[count].y=ty;count++;if(tmap[tx][ty]==FistOfSide[!tside])goto _NOKING;}
	static int i,j,n,x,y;
	static bool	flag;
	count=0;
	for(n=FistOfSide[tside];n<=LastOfSide[tside];n++)
	{
		x=tmanposition[n].x;
		if(!x)continue;
		y=tmanposition[n].y;
		switch(n)
		{
		case 0:
			if(tmanposition[0].x==tmanposition[16].x)		//��˧��ͬһ��
			{
				flag=false;
				for(j=tmanposition[16].y+1;j<tmanposition[0].y;j++)
				{
					if(tmap[x][j]!=32)
					{
						flag=true;
						break;
					}
				}
				if (!flag)	
				{
					ADD(0,x,tmanposition[16].y);
				}
			}
			j=y+1;if(j<=10 && NORED(x,j))	ADD(0,x,j)
			j=y-1;if(j>=8  && NORED(x,j))	ADD(0,x,j)
			i=x+1;if(i<=6  && NORED(i,y))	ADD(0,i,y)
			i=x-1;if(i>=4  && NORED(i,y))	ADD(0,i,y)
			break;
		case 16:
			if(tmanposition[0].x==tmanposition[16].x)		//��˧��ͬһ��
			{
				flag=false;
				for(j=tmanposition[16].y+1;j<tmanposition[0].y;j++)
				{
					if(tmap[x][j]!=32)
					{
						flag=true;
						break;
					}
				}
				if (!flag)	
				{
					ADD(16,x,tmanposition[0].y);
				}
			}
			j=y+1;if(j<=3 && NOBLACK(x,j))	ADD(16,x,j)
			j=y-1;if(j>=1  && NOBLACK(x,j))	ADD(16,x,j)
			i=x+1;if(i<=6  && NOBLACK(i,y))	ADD(16,i,y)
			i=x-1;if(i>=4  && NOBLACK(i,y))	ADD(16,i,y)
			break;
		case 1:
		case 2:
			i=x+1;j=y+1;if(i<=6 && j<=10 && NORED(i,j))	ADD(n,i,j)
			i=x+1;j=y-1;if(i<=6 && j>=8  && NORED(i,j))	ADD(n,i,j)
			i=x-1;j=y+1;if(i>=4 && j<=10 && NORED(i,j))	ADD(n,i,j)
			i=x-1;j=y-1;if(i>=4 && j>=8  && NORED(i,j))	ADD(n,i,j)
			break;
		case 17:
		case 18:
			i=x+1;j=y+1;if(i<=6 && j<=3 && NOBLACK(i,j))	ADD(n,i,j)
			i=x+1;j=y-1;if(i<=6 && j>=1 && NOBLACK(i,j))	ADD(n,i,j)
			i=x-1;j=y+1;if(i>=4 && j<=3	&& NOBLACK(i,j))	ADD(n,i,j)
			i=x-1;j=y-1;if(i>=4 && j>=1 && NOBLACK(i,j))	ADD(n,i,j)
			break;
		case 3:
		case 4:
			i=x+2;j=y+2;if(i<=9 && j<=10   && NORED(i,j))	if(NOMAN(x+1,y+1))	ADD(n,i,j)
			i=x+2;j=y-2;if(i<=9 && j>=6    && NORED(i,j))	if(NOMAN(x+1,y-1))	ADD(n,i,j)
			i=x-2;j=y+2;if(i>=1 && j<=10   && NORED(i,j))	if(NOMAN(x-1,y+1))	ADD(n,i,j)
			i=x-2;j=y-2;if(i>=1 && j>=6    && NORED(i,j))	if(NOMAN(x-1,y-1))	ADD(n,i,j)
			break;
		case 19:
		case 20:
			i=x+2;j=y+2;if(i<=9 && j<=5  && NOBLACK(i,j))	if(NOMAN(x+1,y+1))	ADD(n,i,j)
			i=x+2;j=y-2;if(i<=9 && j>=1  && NOBLACK(i,j))	if(NOMAN(x+1,y-1))	ADD(n,i,j)
			i=x-2;j=y+2;if(i>=1 && j<=5  && NOBLACK(i,j))	if(NOMAN(x-1,y+1))	ADD(n,i,j)
			i=x-2;j=y-2;if(i>=1 && j>=1  && NOBLACK(i,j))	if(NOMAN(x-1,y-1))	ADD(n,i,j)
			break;
		case 5:
		case 6:
			i=x+1;
			if(NOMAN(i,y))
			{
				i=x+2;j=y+1;if(i<=9 && j<=10 && NORED(i,j))	ADD(n,i,j)
				i=x+2;j=y-1;if(i<=9 && j>=1  && NORED(i,j))	ADD(n,i,j)
			}
			i=x-1;
			if(NOMAN(i,y))
			{
				i=x-2;j=y+1;if(i>=1 && j<=10 && NORED(i,j))	ADD(n,i,j)
				i=x-2;j=y-1;if(i>=1 && j>=1  && NORED(i,j))	ADD(n,i,j)
			}
			j=y+1;
			if(NOMAN(x,j))
			{
				i=x+1;j=y+2;if(i<=9 && j<=10 && NORED(i,j))	ADD(n,i,j)
				i=x-1;j=y+2;if(i>=1 && j<=10 && NORED(i,j))	ADD(n,i,j)
			}
			j=y-1;
			if(NOMAN(x,j))
			{
				i=x+1;j=y-2;if(i<=9 && j>=1 && NORED(i,j))	ADD(n,i,j)
				i=x-1;j=y-2;if(i>=1 && j>=1 && NORED(i,j))	ADD(n,i,j)
			}
			break;
		case 21:
		case 22:
			i=x+1;
			if(NOMAN(i,y))
			{
				i=x+2;j=y+1;if(i<=9 && j<=10 && NOBLACK(i,j))	ADD(n,i,j)
				i=x+2;j=y-1;if(i<=9 && j>=1  && NOBLACK(i,j))	ADD(n,i,j)
			}
			i=x-1;
			if(NOMAN(i,y))
			{
				i=x-2;j=y+1;if(i>=1 && j<=10 && NOBLACK(i,j))	ADD(n,i,j)
				i=x-2;j=y-1;if(i>=1 && j>=1  && NOBLACK(i,j))	ADD(n,i,j)
			}
			j=y+1;
			if(NOMAN(x,j))
			{
				i=x+1;j=y+2;if(i<=9 && j<=10 && NOBLACK(i,j))	ADD(n,i,j)
				i=x-1;j=y+2;if(i>=1 && j<=10 && NOBLACK(i,j))	ADD(n,i,j)
			}
			j=y-1;
			if(NOMAN(x,j))
			{
				i=x+1;j=y-2;if(i<=9 && j>=1 && NOBLACK(i,j))	ADD(n,i,j)
				i=x-1;j=y-2;if(i>=1 && j>=1 && NOBLACK(i,j))	ADD(n,i,j)
			}
			break;

		case 7:
		case 8:
				i=x+1;
				while(i<=9)
				{
					if (NOMAN(i,y))	ADD(n,i,y)
					else
					{
						if(NORED(i,y))	ADD(n,i,y)
						break;
					}
					i++;
				}
				i=x-1;
				while(i>=1)
				{
					if (NOMAN(i,y))	ADD(n,i,y)
					else
					{
						if(NORED(i,y))	ADD(n,i,y)
						break;
					}
					i--;
				}
				j=y+1;
				while(j<=10)
				{
					if (NOMAN(x,j))	ADD(n,x,j)
					else
					{
						if(NORED(x,j))	ADD(n,x,j)
						break;
					}
					j++;
				}
				j=y-1;
				while(j>=1)
				{
					if (NOMAN(x,j))	ADD(n,x,j)
					else
					{
						if(NORED(x,j))	ADD(n,x,j)
						break;
					}
					j--;
				}
				break;
		case 23:
		case 24:
				i=x+1;
				while(i<=9)
				{
					if (NOMAN(i,y))	ADD(n,i,y)
					else
					{
						if(NOBLACK(i,y))	ADD(n,i,y)
						break;
					}
					i++;
				}
				i=x-1;
				while(i>=1)
				{
					if (NOMAN(i,y))	ADD(n,i,y)
					else
					{
						if(NOBLACK(i,y))	ADD(n,i,y)
						break;
					}
					i--;
				}
				j=y+1;
				while(j<=10)
				{
					if (NOMAN(x,j))	ADD(n,x,j)					
					else
					{
						if(NOBLACK(x,j))	ADD(n,x,j)
						break;
					}
					j++;
				}
				j=y-1;
				while(j>=1)
				{
					if (NOMAN(x,j))	ADD(n,x,j)
					else
					{
						if(NOBLACK(x,j))	ADD(n,x,j)
						break;
					}
					j--;
				}
				break;
		case 9:
		case 10:
			i=x+1;flag=false;
			while(i<=9)
			{
				if(NOMAN(i,y))
				{
					if(!flag)	ADD(n,i,y)
				}
				else
				{
					if(!flag)flag=true;
					else 
					{
						if(NORED(i,y))	ADD(n,i,y)
						break;
					}
				}
				i++;
			}

			i=x-1;flag=false;
			while(i>=1)
			{
				if(NOMAN(i,y)) 
				{
					if(!flag)	ADD(n,i,y)
				}
				else
				{
					if(!flag)flag=true;
					else 
					{
						if(NORED(i,y))	ADD(n,i,y)
						break;
					}
				}
				i--;
			}

			j=y+1;flag=false;
			while(j<=10)
			{
				if(NOMAN(x,j)) 
				{
					if(!flag)	ADD(n,x,j)
				}
				else
				{
					if(!flag)flag=true;
					else 
					{
						if(NORED(x,j))	ADD(n,x,j)
						break;
					}
				}
				j++;
			}

			j=y-1;flag=false;
			while(j>=1)
			{
				if(NOMAN(x,j)) 
				{
					if(!flag)	ADD(n,x,j)
				}
				else
				{
					if(!flag)flag=true;
					else 
					{
						if(NORED(x,j))	ADD(n,x,j)
						break;
					}
				}
				j--;
			}
			break;

		case 25:
		case 26:
			i=x+1;flag=false;
			while(i<=9)
			{
				if(NOMAN(i,y))
				{
					if(!flag)	ADD(n,i,y)
				}
				else
				{
					if(!flag)flag=true;
					else
					{
						if(NOBLACK(i,y))	ADD(n,i,y)
						break;
					}
				}
				i++;
			}

			i=x-1;flag=false;
			while(i>=1)
			{
				if(NOMAN(i,y)) 
				{
					if(!flag)	ADD(n,i,y)
				}
				else
				{
					if(!flag)flag=true;
					else 
					{
						if(NOBLACK(i,y))	ADD(n,i,y)
						break;
					}
				}
				i--;
			}

			j=y+1;flag=false;
			while(j<=10)
			{
				if(NOMAN(x,j))
				{
					if(!flag)	ADD(n,x,j)
				}
				else
				{
					if(!flag)flag=true;
					else 
					{
						if(NOBLACK(x,j))	ADD(n,x,j)
						break;
					}
				}
				j++;
			}

			j=y-1;flag=false;
			while(j>=1)
			{
				if(NOMAN(x,j))
				{
					if(!flag)	ADD(n,x,j)
				}
				else
				{
					if(!flag)flag=true;
					else 
					{
						if(NOBLACK(x,j))	ADD(n,x,j)
						break;
					}
				}
				j--;
			}
			break;
		case 11:
		case 12:
		case 13:
		case 14:
		case 15:
			j=y-1;
			if(j>=1 && NORED(x,j))	ADD(n,x,j)
			if(y<=5)
			{
				i=x+1;if(i<=9 && NORED(i,y))	ADD(n,i,y)
				i=x-1;if(i>=1 && NORED(i,y))	ADD(n,i,y)
			}
			break;

		case 27:
		case 28:
		case 29:
		case 30:
		case 31:
			j=y+1;
			if(j<=10 && NOBLACK(x,j))	ADD(n,x,j)
			if(y>=6)
			{
				i=x+1;if(i<=9 && NOBLACK(i,y))	ADD(n,i,y)
				i=x-1;if(i>=1 && NOBLACK(i,y))	ADD(n,i,y)
			}
			break;
		default :
			break;
		}
	}
	return true;
_NOKING:
	return false;
}

/******************************************************************
ContactV:	��������ӵĻ�Ծ�Ⱥ����Ӽ����ϵֵ��ΪValue�������Ӻ���

����:
tmap:			����λ״̬
tmanposition:	32���ӵ�����
tside:			�ֵ���һ����
activity:		���ӵĻ�Ծ�ȣ���Ž����
contact:		���Ӽ����ϵֵ����Ž����	
	
����ֵ:		��
******************************************************************/
void ContactV(int tmap[11][12],POINT tmanposition[32],int &tside,int activity[32],int contact[32][32])
{

	#define CV(man,tx,ty) {k=tmap[tx][ty];activity[man]+=1;if(k!=32)contact[man][k]=1;}

	static int k;
	static int i,j,n,x,y;
	static bool	flag;

	for(n=0;n<=31;n++)
	{
		x=tmanposition[n].x;
		if(!x)continue;
		y=tmanposition[n].y;
		switch(n)
		{
		case 0:
			if(tmanposition[0].x==tmanposition[16].x)		//��˧��ͬһ��
			{
				flag=false;
				for(j=tmanposition[16].y+1;j<tmanposition[0].y;j++)
				{
					if(tmap[x][j]!=32)
					{
						flag=true;
						break;
					}
				}
				if (!flag)	
				{
					CV(0,x,tmanposition[16].y);
				}
			}
			j=y+1;if(j<=10 )	CV(0,x,j)
			j=y-1;if(j>=8  )	CV(0,x,j)
			i=x+1;if(i<=6  )	CV(0,i,y)
			i=x-1;if(i>=4  )	CV(0,i,y)
			break;
		case 16:
			if(tmanposition[0].x==tmanposition[16].x)		//��˧��ͬһ��
			{
				flag=false;
				for(j=tmanposition[16].y+1;j<tmanposition[0].y;j++)
				{
					if(tmap[x][j]!=32)
					{
						flag=true;
						break;
					}
				}
				if (!flag)	
				{
					CV(16,x,tmanposition[0].y);
				}
			}
			j=y+1;if(j<=3 )	CV(16,x,j)
			j=y-1;if(j>=1 )	CV(16,x,j)
			i=x+1;if(i<=6 )	CV(16,i,y)
			i=x-1;if(i>=4 )	CV(16,i,y)
			break;
		case 1:
		case 2:
			i=x+1;j=y+1;if(i<=6 && j<=10 )	CV(n,i,j)
			i=x+1;j=y-1;if(i<=6 && j>=8  )	CV(n,i,j)
			i=x-1;j=y+1;if(i>=4 && j<=10 )	CV(n,i,j)
			i=x-1;j=y-1;if(i>=4 && j>=8  )	CV(n,i,j)
			break;
		case 17:
		case 18:
			i=x+1;j=y+1;if(i<=6 && j<=3 )	CV(n,i,j)
			i=x+1;j=y-1;if(i<=6 && j>=1 )	CV(n,i,j)
			i=x-1;j=y+1;if(i>=4 && j<=3	)	CV(n,i,j)
			i=x-1;j=y-1;if(i>=4 && j>=1 )	CV(n,i,j)
			break;
		case 3:
		case 4:
			i=x+2;j=y+2;if(i<=9 && j<=10  )	if(NOMAN(x+1,y+1))	CV(n,i,j)
			i=x+2;j=y-2;if(i<=9 && j>=6   )	if(NOMAN(x+1,y-1))	CV(n,i,j)
			i=x-2;j=y+2;if(i>=1 && j<=10  )	if(NOMAN(x-1,y+1))	CV(n,i,j)
			i=x-2;j=y-2;if(i>=1 && j>=6   )	if(NOMAN(x-1,y-1))	CV(n,i,j)
			break;
		case 19:
		case 20:
			i=x+2;j=y+2;if(i<=9 && j<=5 )	if(NOMAN(x+1,y+1))	CV(n,i,j)
			i=x+2;j=y-2;if(i<=9 && j>=1 )	if(NOMAN(x+1,y-1))	CV(n,i,j)
			i=x-2;j=y+2;if(i>=1 && j<=5 )	if(NOMAN(x-1,y+1))	CV(n,i,j)
			i=x-2;j=y-2;if(i>=1 && j>=1 )	if(NOMAN(x-1,y-1))	CV(n,i,j)
			break;
		case 5:
		case 6:
			i=x+1;
			if(NOMAN(i,y))
			{
				i=x+2;j=y+1;if(i<=9 && j<=10 )	CV(n,i,j)
				i=x+2;j=y-1;if(i<=9 && j>=1  )	CV(n,i,j)
			}
			i=x-1;
			if(NOMAN(i,y))
			{
				i=x-2;j=y+1;if(i>=1 && j<=10 )	CV(n,i,j)
				i=x-2;j=y-1;if(i>=1 && j>=1  )	CV(n,i,j)
			}
			j=y+1;
			if(NOMAN(x,j))
			{
				i=x+1;j=y+2;if(i<=9 && j<=10 )	CV(n,i,j)
				i=x-1;j=y+2;if(i>=1 && j<=10 )	CV(n,i,j)
			}
			j=y-1;
			if(NOMAN(x,j))
			{
				i=x+1;j=y-2;if(i<=9 && j>=1 )	CV(n,i,j)
				i=x-1;j=y-2;if(i>=1 && j>=1 )	CV(n,i,j)
			}
			break;
		case 21:
		case 22:
			i=x+1;
			if(NOMAN(i,y))
			{
				i=x+2;j=y+1;if(i<=9 && j<=10 )	CV(n,i,j)
				i=x+2;j=y-1;if(i<=9 && j>=1  )	CV(n,i,j)
			}
			i=x-1;
			if(NOMAN(i,y))
			{
				i=x-2;j=y+1;if(i>=1 && j<=10 )	CV(n,i,j)
				i=x-2;j=y-1;if(i>=1 && j>=1  )	CV(n,i,j)
			}
			j=y+1;
			if(NOMAN(x,j))
			{
				i=x+1;j=y+2;if(i<=9 && j<=10 )	CV(n,i,j)
				i=x-1;j=y+2;if(i>=1 && j<=10 )	CV(n,i,j)
			}
			j=y-1;
			if(NOMAN(x,j))
			{
				i=x+1;j=y-2;if(i<=9 && j>=1 )	CV(n,i,j)
				i=x-1;j=y-2;if(i>=1 && j>=1 )	CV(n,i,j)
			}
			break;

		case 7:
		case 8:
				i=x+1;
				while(i<=9)
				{
					if (NOMAN(i,y))	CV(n,i,y)
					else
					{
						CV(n,i,y)
						break;
					}
					i++;
				}
				i=x-1;
				while(i>=1)
				{
					if (NOMAN(i,y))	CV(n,i,y)
					else
					{
						CV(n,i,y)
						break;
					}
					i--;
				}
				j=y+1;
				while(j<=10)
				{
					if (NOMAN(x,j))	CV(n,x,j)
					else
					{
						CV(n,x,j)
						break;
					}
					j++;
				}
				j=y-1;
				while(j>=1)
				{
					if (NOMAN(x,j))	CV(n,x,j)
					else
					{
						CV(n,x,j)
						break;
					}
					j--;
				}
				break;
		case 23:
		case 24:
				i=x+1;
				while(i<=9)
				{
					if (NOMAN(i,y))	CV(n,i,y)
					else
					{
						CV(n,i,y)
						break;
					}
					i++;
				}
				i=x-1;
				while(i>=1)
				{
					if (NOMAN(i,y))	CV(n,i,y)
					else
					{
						CV(n,i,y)
						break;
					}
					i--;
				}
				j=y+1;
				while(j<=10)
				{
					if (NOMAN(x,j))	CV(n,x,j)					
					else
					{
						CV(n,x,j)
						break;
					}
					j++;
				}
				j=y-1;
				while(j>=1)
				{
					if (NOMAN(x,j))	CV(n,x,j)
					else
					{
						CV(n,x,j)
						break;
					}
					j--;
				}
				break;
		case 9:
		case 10:
			i=x+1;flag=false;
			while(i<=9)
			{
				if(NOMAN(i,y))
				{
					if(!flag)	CV(n,i,y)
				}
				else
				{
					if(!flag)flag=true;
					else 
					{
						CV(n,i,y)
						break;
					}
				}
				i++;
			}

			i=x-1;flag=false;
			while(i>=1)
			{
				if(NOMAN(i,y)) 
				{
					if(!flag)	CV(n,i,y)
				}
				else
				{
					if(!flag)flag=true;
					else 
					{
						CV(n,i,y)
						break;
					}
				}
				i--;
			}

			j=y+1;flag=false;
			while(j<=10)
			{
				if(NOMAN(x,j)) 
				{
					if(!flag)	CV(n,x,j)
				}
				else
				{
					if(!flag)flag=true;
					else 
					{
						CV(n,x,j)
						break;
					}
				}
				j++;
			}

			j=y-1;flag=false;
			while(j>=1)
			{
				if(NOMAN(x,j)) 
				{
					if(!flag)	CV(n,x,j)
				}
				else
				{
					if(!flag)flag=true;
					else 
					{
						CV(n,x,j)
						break;
					}
				}
				j--;
			}
			break;

		case 25:
		case 26:
			i=x+1;flag=false;
			while(i<=9)
			{
				if(NOMAN(i,y))
				{
					if(!flag)	CV(n,i,y)
				}
				else
				{
					if(!flag)flag=true;
					else
					{
						CV(n,i,y)
						break;
					}
				}
				i++;
			}

			i=x-1;flag=false;
			while(i>=1)
			{
				if(NOMAN(i,y)) 
				{
					if(!flag)	CV(n,i,y)
				}
				else
				{
					if(!flag)flag=true;
					else 
					{
						CV(n,i,y)
						break;
					}
				}
				i--;
			}

			j=y+1;flag=false;
			while(j<=10)
			{
				if(NOMAN(x,j))
				{
					if(!flag)	CV(n,x,j)
				}
				else
				{
					if(!flag)flag=true;
					else 
					{
						CV(n,x,j)
						break;
					}
				}
				j++;
			}

			j=y-1;flag=false;
			while(j>=1)
			{
				if(NOMAN(x,j))
				{
					if(!flag)	CV(n,x,j)
				}
				else
				{
					if(!flag)flag=true;
					else 
					{
						CV(n,x,j)
						break;
					}
				}
				j--;
			}
			break;
		case 11:
		case 12:
		case 13:
		case 14:
		case 15:
			j=y-1;
			if(j>=1 )	CV(n,x,j)
			if(y<=5)
			{
				i=x+1;if(i<=9 )	CV(n,i,y)
				i=x-1;if(i>=1 )	CV(n,i,y)
			}
			break;

		case 27:
		case 28:
		case 29:
		case 30:
		case 31:
			j=y+1;
			if(j<=10 )	CV(n,x,j)
			if(y>=6)
			{
				i=x+1;if(i<=9 )	CV(n,i,y)
				i=x-1;if(i>=1 )	CV(n,i,y)
			}
			break;
		default :
			break;
		}
	}
}

/******************************************************************
Search:			��-�µݹ���������man,point��ɵ��߷��ļ�ֵ

����:
tmap:			����λ״̬
tmanposition:	32���ӵ�����
tside:			�ֵ���һ����
man:			���ƶ�������
point:			Ŀ��λ��,��man����߷�
upmax:			��һ������ֵ����������-�¼�֦
depth:			���������

����ֵ:			�����߷��ļ�ֵ
******************************************************************/
int Search(int tmap[11][12],POINT tmanposition[32],int &tside,int man, POINT point,int upmax,int depth)
{

	int ate,cur,maxvalue,curvalue,xs,ys;
	int count;

	ate=32;
	//�ƶ�����:
	xs=tmanposition[man].x;ys=tmanposition[man].y;				//ԭ����
	if (SideOfMan[tmap[point.x][point.y]]==!tside)	//Ŀ����жԷ�������
	{
		ate=tmap[point.x][point.y];					//��¼�±��Ե�������
		if(ate==0 || ate==16)
		{
			return 9999;
		}
		tmanposition[ate].x=0;						//Ŀ�������ӱ��Ե�
//		tmancount--;
	}
	depth--;
	tmap[point.x][point.y]=man;						//��������:
	tmap[xs][ys]=32;							//��map�ϵ��ƶ�
	tmanposition[man]=point;						
	tside=!tside;

	if(depth>0)
	{
		int chessman[125];
		POINT targetpoint[125];
		if(EnumList(tmap,tmanposition,tside,chessman,targetpoint,count))
		{
			if(depth>=2 && count>S_WIDTH+2)
			{
				int value[125];
				cur=0;
				maxvalue=-10000;
				while(cur< count)
				{
					curvalue=Search(tmap,tmanposition,tside,chessman[cur],targetpoint[cur],-10000,depth-2);
					value[cur]=curvalue;
					if(curvalue>maxvalue)maxvalue=curvalue;
					cur ++;
				}
				::Mantis_QuickSort(value,chessman,targetpoint,0,count-1);
				count=S_WIDTH;
			}

			maxvalue=-10000;
			cur=0;
			while(cur< count)
			{
				curvalue=Search(tmap,tmanposition,tside,chessman[cur],targetpoint[cur],maxvalue,depth);
				if(curvalue>maxvalue)maxvalue=curvalue;
				if(curvalue>=-upmax)goto _ENDSUB;
				cur ++;
			}
		}
		else maxvalue=9800;
	}
	else
	{
		maxvalue=Value(tmap,tmanposition,tside);
	}

_ENDSUB:
	tmanposition[man].x=xs;							//��������:
	tmanposition[man].y=ys;							//��face�ϵĻָ�
	tmap[xs][ys]=man;									//��map�ϵĻָ�
	if(ate!=32)
	{
		tmanposition[ate]=point;
		tmap[point.x][point.y]=ate;
//		tmancount++;
	}
	else tmap[point.x][point.y]=32;

	tside=!tside;
	return -maxvalue;
}

/******************************************************************
Think:			������߷�

����:
tmap:			����λ״̬
tmanposition:	32���ӵ�����
tside:			�ֵ���һ����
resultman:		����ƶ�������
resultpoint:	����ƶ�Ŀ��λ��

����ֵ:			�ɹ�����true,���򷵻�false
******************************************************************/
bool Think(int tmap[11][12],POINT tmanposition[32],int &tside,int &resultman, POINT &resultpoint)
{
	int chessman[125];
	POINT targetpoint[125];
	int count;
	int maxvalue;
	int cur;
	int curvalue;
	if(EnumList(tmap,tmanposition,tside,chessman,targetpoint,count))
	{
		if(S_DEPTH>=2 && count>S_WIDTH+2)
		{
			int value[125];
			cur=0;
			maxvalue=-10000;
			while(cur< count)
			{
				curvalue=Search(tmap,tmanposition,tside,chessman[cur],targetpoint[cur],-10000,S_DEPTH-2);
				value[cur]=curvalue;
				if(curvalue>maxvalue)maxvalue=curvalue;
				cur ++;
			}
			::Mantis_QuickSort(value,chessman,targetpoint,0,count-1);
			count=S_WIDTH;
		}
		maxvalue=-10000;
		cur=0;
		while(cur< count)
		{
			curvalue=Search(tmap,tmanposition,tside,chessman[cur],targetpoint[cur],maxvalue,S_DEPTH);
			if(curvalue>maxvalue)
			{
				maxvalue=curvalue;
				resultman=chessman[cur];
				resultpoint=targetpoint[cur];
			}
			cur ++;
		}
		return true;
	}
	else
	{
		if(count>0)
		{
			resultman=chessman[count-1];
			resultpoint=targetpoint[count-1];
			return true;
		}
		else
		{
			resultman=32;
			resultpoint.x=0;
			return false;
		}
	}
}
