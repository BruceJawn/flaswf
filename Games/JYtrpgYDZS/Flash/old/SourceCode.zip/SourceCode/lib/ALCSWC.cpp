/**
 *Console RPG ��ӹȺ�������ְ�
 *jiqing
 *http://hi.baidu.com/jiqing0925
 *jiqingwu@gmail.com

 *Console RPG Flash Port
 *February 11, 2011
 *Bruce Jawn
 *http://bruce-lab.blogspot.com
 *zhoubu1988@gmail.com
 
 *Copyright (c) <2011> <jiqing, Bruce Jawn>
 *This software is released under GNU GENERAL PUBLIC LICENSE Version 3
 *<www.gnu.org/licenses/gpl-3.0.html>
 **/
#include "AS3.h"
//#include <stdio.h>

AS3_Val AS_Main;
unsigned int TextColor = 0x000000;
void printf2(const char *type,const char *str)
{     //printf("%d",value);
	  //AS3_Trace(AS3_String("printf"));
      AS3_CallTS("Print", AS_Main, "StrType, IntType", str, TextColor);
}
#include "MyOutstream.cpp"
MyOutstream cout;//��ʱ���Ϊ���Ƿ����ȫ�ֶ���myout 
MyOutstream cerr;//��ʱ���Ϊ���Ƿ����ȫ�ֶ���myout 
//#define endl_Bruce_Jawn ' '
char* endl_Bruce_Jawn="\n";

#include "CFight.h"
#include "CGame.h"
#include "global.h"
//#include "TextParser.h"
#include "TextParser.cpp"
#include "CGame.cpp"
#include "save.cpp"
//#include "MyOutstream.cpp"
//#include "global.cpp"
#include "CFight.cpp"


///
int/*HANDLE*/ hConsole=0;	//output stream handle
CGame * g_pGame;
///

AS3_Val initialize(void* self, AS3_Val args)
{
AS3_ArrayValue(args,"AS3ValType",&AS_Main);
g_pGame = new CGame( hConsole );
g_pGame->Init( hConsole );
g_pGame->RunGame();	
delete g_pGame;
}//end of initialize

AS3_Val SAVE_flash(void* self, AS3_Val args)
{
	g_pGame->SavePlayerData_Flash();
	return  AS3_Int(0);
}//end of SAVE_flash

	int main()
{
	AS3_Val initializeMethod = /*AS3_Function*/AS3_FunctionAsync( NULL, initialize);
	AS3_Val SAVE_flashMethod = AS3_Function( NULL, SAVE_flash);
	AS3_Val result = AS3_Object("initialize: AS3ValType, SAVE_flash: AS3ValType",initializeMethod,SAVE_flashMethod);
	AS3_Release( initializeMethod );
	AS3_Release( SAVE_flashMethod );
	AS3_LibInit( result );
	return 0;
}//end of main


/*
int main()
{	
#ifdef _WIN32_
	hConsole = GetStdHandle( STD_OUTPUT_HANDLE );
#else
    hConsole = 0;
#endif

#ifndef _WIN32_
    struct termios oldt, newt;
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ECHO|ICANON);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
#endif
	g_pGame = new CGame( hConsole );
	g_pGame->RunGame();	
	delete g_pGame;

#ifndef _WIN32_
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
#endif

    return 0;
}
*/
