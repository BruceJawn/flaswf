bool CGame::SavePlayerData_Flash()
{
	//�򿪴浵�ļ�
	//ofstream hSaveFile( "save.dat");
	/*if (!hSaveFile)
	{
		cerr << "open save file failed !" << endl_Bruce_Jawn;
		return false;
	}*/
	AS3_Val flash_utils_namespace = AS3_String("flash.utils");
    AS3_Val ByteArray_class = AS3_NSGetS(flash_utils_namespace, "ByteArray");
    AS3_Val byteArray = AS3_New(ByteArray_class, AS3_Array(""));

	//д�������������

	AS3_ByteArray_writeBytes(byteArray, reinterpret_cast<char *> (&pNpcs[0]), sizeof (CRole));//hSaveFile.write( reinterpret_cast<char *> (&pNpcs[0]), sizeof (CRole) );
	AS3_ByteArray_writeBytes(byteArray, reinterpret_cast<char *> (&oGameEnv.nCurrentMap), sizeof(short));//hSaveFile.write( reinterpret_cast<char *> (&oGameEnv.nCurrentMap), sizeof(short));

	short i, j;

	//д�������־
	for( i= 0; i < nQuestsNum; ++ i )
		AS3_ByteArray_writeBytes(byteArray, reinterpret_cast<char *>(& pQuests[i].nFlagValue), sizeof (CRole));//hSaveFile.write( reinterpret_cast<char *>(& pQuests[i].nFlagValue), sizeof(short) );
    for(i =0; i < VAR_NUM; ++i)
        AS3_ByteArray_writeBytes(byteArray, reinterpret_cast<char *>(& nVars[i]), sizeof (CRole));//hSaveFile.write( reinterpret_cast<char *>(& nVars[i]), sizeof(short) );

	//д���������npc�� free item�����

    /*
	for( i= 0; i < nSpotsNum; ++i )
	{
		hSaveFile.write( reinterpret_cast<char *>(&pSpots[i].nNpcNum), sizeof(short) );
		for(j = 0; j < pSpots[i].nNpcNum; ++j )
			hSaveFile.write( reinterpret_cast<char *>(&pSpots[i].nNpcs[j]), sizeof(short) );

		hSaveFile.write( reinterpret_cast<char *>(&pSpots[i].nGoodsNum), sizeof(short));			
		for(j = 0; j < pSpots[i].nGoodsNum; ++j )
			hSaveFile.write( reinterpret_cast<char *>(&pSpots[i].nGoods[j]), sizeof(short) );
	}
    */
    AS3_CallTS("SAVE", AS_Main, "AS3ValType,StrType", byteArray,"save.dat");
	AS3_Release(flash_utils_namespace);
    AS3_Release(ByteArray_class);
	AS3_Release(byteArray);
    return true;
}