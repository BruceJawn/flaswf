int MyLife;
//int Status;
int speed;
int armor;
int power;

int Tspeed;
int Tarmor;
int Tpower;
AS3_Val newGame(void* self, AS3_Val args)
{
	initGame();
	return 0;
}
void initGame()
{
	MyLife=100;
	//Status=0;
	speed=1;
	armor=0;
	power=0;
	Tspeed=50;
	Tarmor=50;
	Tpower=50;
	cy0=131072;//2<<16;
	cx0=131072;//2<<16;
	cheight=96;
	//global
	gu0=L((cx0>>16));
	gv0=L((cy0>>16));
	guv=gu0<<8|gv0;
	//global
}

void loopGame()
{
	if(Tspeed<=0)
	{
		speed=1;
	}
	if(Tarmor<=0)
	{
		armor=0;
	}
	if(Tpower<=0)
	{
		power=0;
	}
	if(MyLife<=0||cheight<-25)//
	{
		AS3_CallTS("resetGame", AS_Main, "StrType",("Lose"));//resetGame();
		initGame();
	}
	else if(cx0>16646144/*(254<<16)*/&&cy0>16646144/*(254<<16)*/)
	{
		//printf("resetGame");
		AS3_CallTS("resetGame", AS_Main, "StrType",("Win"));//resetGame();
		initGame();
	}

}
//
AS3_Val calculateRemain(void* self, AS3_Val args)
{
	int i;
	int left=0;
	for(i=0;i<0x80ffff;i++)
	{
		if(voxdata[i])
		{
			left++;
		}
	}//end of for
	return AS3_Int(left);
}