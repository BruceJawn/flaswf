#include <stdio.h>
#include <stdlib.h>

AS3_Val loadvoxdata(void* self, AS3_Val args)
{
	//cx0=0;
	//cy0=0;
	//cheight=100;
	//initGame();
	voxdata = malloc(0x80ffff * sizeof(int));
	return AS3_Ptr( voxdata );
}
//����HMap0����256��CMap256����0
AS3_Val ComputeMap(void* self, AS3_Val args) {
	int i, j, k;
	for ( i=0; i<256; i++) {
		for ( j=0; j<256; j++) {
			for(k=0; k<128; k++)
			{if(voxdata[k<<16|i<<8|j]>0){HMap[i<<8|j]=k;break;}}
			//HMap[i<<8|j]=0;
			for(k=128; k>-1; k--)
			{if(voxdata[k<<16|i<<8|j]>0){CMap[i<<8|j]=k+1;break;}}
			//CMap[i<<8|j]=300;
		}//end of for1
	}//end of for2

	return 0;
}//end of ComputeMap()
