float Sin_LUT[360];
float Cos_LUT[360];
//float Tan_LUT[360];

void Build_sct_table(void)
{
	int angle;
	float rad;
	for(angle=0;angle<360;angle++)
	{
		rad=angle*0.017453;
		Sin_LUT[angle]=(int)((sin(rad))*65536);
		Cos_LUT[angle]=(int)((cos(rad))*65536);
		//Tan_LUT[angle]=tan(rad);
	}//end of for

}//end of void Build_sct_table