int gu0,gv0,guv;
int check_hit_floor()
{
	//int u0,v0,uv/*,i*/;
	//u0=L((cx0>>16));
	//v0=L((cy0>>16));
	//uv=u0<<8|v0;
	if(voxdata[L2(cheight+1)<<16|guv]/*>0*/)
	{cheight=L(cheight+3);
	return 0;} 
	if(voxdata[L2(cheight)<<16|guv]/*>0*/)
	{cheight=L(cheight+2);
	return 0;}
	if(voxdata[L2(cheight-1)<<16|guv]/*>0*/)
	{cheight=L(cheight+1);
	return 0;} 
	if(voxdata[L2(cheight-2)<<16|guv]/*>0*/)
	{
		return 0;
	}
	else
		return 1;

}//end of do_physics

int check_hit_ceil()
{
	//int u0,v0,uv;
	//u0=L((cx0>>16));
	//v0=L((cy0>>16));
	//uv=u0<<8|v0;
	if(voxdata[L2(cheight+1)<<16|guv]/*>0*/)
		return 1;
	else
		return 0;
}//end of do_physics

int check_hit_move()
{
	//int u0,v0,uv;
	//u0=L((cx0>>16));
	//v0=L((cy0>>16));
	//uv=u0<<8|v0;
	if(voxdata[L2(cheight+1)<<16|guv]/*>0*/)
		return 1;
	//else if(voxdata[L2(cheight+2)<<16|guv]>0)
	//return 1;
	else
		return 0;
}//end of do_physics

void do_gravity()
{
	if(check_hit_floor())
		cheight--;
}
