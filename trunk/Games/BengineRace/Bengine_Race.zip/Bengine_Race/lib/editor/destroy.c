/*unsigned*/ //int brush_color=0xff0000;
/*unsigned*/ //int brush_scale=4;
void destroy()
{
	int i,j,k;
	int u0,v0,uv;
	for(i=-3;i<3;i++)
		for(j=-3;j<3;j++)
			for(k=-3;k<3;k++)
			{
				u0=L((cx0>>16)+i);
				v0=L((cy0>>16)+j);
				uv=u0<<8|v0;
				if(voxdata[L2(cheight+k)<<16|uv]/*>0*/)
				{
					voxdata[L2(cheight+k)<<16|uv]=0;
				}//end of if
			}//end of for 
}//end of destroy
/*
void create()
{
int i,j,k;
int u0,v0,uv;
for(i=-brush_scale;i<brush_scale;i++)
{
for(j=-brush_scale;j<brush_scale;j++){
u0=L((cx0>>16)+i);
v0=L((cy0>>16)+j);
uv=u0<<8|v0;
for(k=-brush_scale;k<brush_scale;k++)
{
//if(voxdata[uv|L(cheight+k)]==0)
//{
voxdata[L2(cheight+k)<<16|uv]=brush_color;	   
//}//end of if
}//end of for k
//((cheight+10)<256)?(CMap[u0<<8|v0]=cheight+10):(CMap[u0<<8|v0]=255);
if(HMap[u0<<8|v0]>L2(cheight-brush_scale))
HMap[u0<<8|v0]=L2(cheight-brush_scale);
}//end of for j
}//end of for i    
}//end of create
*/