if(columcnt[i]==191){continue;}
down=HMap[uv/*u0<<8|v0*/];//small
if(down<sHd)down=sHd;//???????????????????????
top=CMap[uv/*u0<<8|v0*/];//big
if(top>sHt)top=sHt;
height=top-down;
if(height<1){continue;}

yf=y000+y0255*down;//
yc=y000+y0255*top;//
//==============================
if(yf>191){continue;}
if(yc<0){continue;}

if((yc-yf)<1){continue;}
//ycf=(yc-yf);
//if(ycf<1){continue;}

//ddd=height/ycf;


crayz=down;
if(yf<0){crayz=-ddd*y000/*down+ddd*(-yf)*/;yf=0;}
if(yc>191){yc=191;}

yf=(int)(yf);
yc=(int)(yc);
//������columcnt�������voxdata��tBuffer��˳��
ddd=1/ddd;//voxel2screen 1voxel x
for(;crayz<top,y<yc;crayz++)
{

	c=voxdata[L2((int)(crayz))<<16|uv];
	if(c/*>0*/){
		for(y=0;y<ddd;y++)
			b= ((191-y-yf)<<8)|i;//+i;//*256<<8?
		if(!tBuffer[b])//(tBuffer[b]==0)
		{tBuffer[b]=c;
		columcnt[i]++;
		}

	}//end of if(c>0)
	yf+=ddd;//crayz+=ddd;//=ddd;
}//end of for for(y=yf;y<yc;y++)
//===============================