//#include <math.h>
#include <string.h>
//#include "def_var.c"
#include "tables/lookuptable.c"
float screenAt;//=1/tan(3.14159265358979/4)*160;
char/*int**/ columcnt[256];
//======================
float project_s_t[256];//[135];
float project_is_t[256];
//======================
void  init_raytable()
{
	int d=0;
	for (d=0; d<256; d+=1+(d>>6)) {				       
		project_s_t[d]=screenAt/d;
		project_is_t[d]=d/screenAt;
	}//end of for ( d=0; d<100; d+=1+(d>>6) )
}//end of void  init_raytable

//======================
inline int L(int x) {
	return x & 0xff;
}//end of int L
inline int L2(int x) {
	//return x<0?x+128:x%0x80;
	return x&(0x80-1);
}//end of int L


void  Line(int x0, int y0, int x1, int y1, int hy, float s, float is){
	int i, sx, sy;
	//Compute xy speed
	sx=x1>>8;//(x1-x0)>>8;//256;
	sy=y1>>8;//(y1-y0)>>8;//256;

	int /*h ,*/u0, v0, uv,/* a,*/ b;
	int y;
	unsigned int c;

	float y000/*,y255*/,y0255;
	int down,top,height;
	float yf,yc,/*ycf,*/ddd,crayz;

	//=========================
	y000=-cheight*s+MidOut;//(0-cheight)*s+MidOut;
	//y255=(255-cheight)*s+MidOut;
	y0255=s;//(y255-y000)/256//>>8;///256;//256;
	//=========================

	ddd=is;//1/s;//256
	//=========================
	int screenHhalf=96*is;///s;
	int sHd=(cheight-screenHhalf-MidOut*is/*/s*/);//????????????????
	int sHt=(cheight+screenHhalf);//-MidOut/s);
	//=========================

	for (i=0; i<256; i++) {

		//Compute the xy coordinates; a and b will be the position inside the
		//single map cell (0..255).
		u0=L(x0>>16);
		v0=L(y0>>16);
		uv=u0<<8|v0;
		// Advance to next xy position
		x0+=sx;
		y0+=sy;
		//=================================================================
		if(columcnt[i]==191){continue;}
		down=HMap[uv/*u0<<8|v0*/];//small
		if(down<sHd)down=sHd;//???????????????????????
		top=CMap[uv/*u0<<8|v0*/];//big
		if(top>sHt)top=sHt;
		height=top-down;
		if(height<1){continue;}

		yf=y000+y0255*down;
		yc=y000+y0255*top;
		//==============================
		if(yf>191){continue;}
		if(yc<0){continue;}

		if((yc-yf)<1){continue;}
		//ycf=(yc-yf);
		//if(ycf<1){continue;}

		//ddd=height/ycf;


		crayz=down;
		if(yf<0){crayz=-ddd*y000/*down+ddd*(-yf)*/;yf=0;}
		if(yc>191){yc=191;}

		yf=(int)(yf);
		yc=(int)(yc);
		//������columcnt�������voxdata��tBuffer��˳��

		for(y=yf;y<yc;y++)
		{

			c=voxdata[L2((int)(crayz))<<16|uv];
			if(c/*>0*/){
				b= ((191-y)<<8)|i;//+i;//*256<<8?
				if(!tBuffer[b])//(tBuffer[b]==0)
				{tBuffer[b]=c;
				columcnt[i]++;
				}

			}//end of if(c>0)
			crayz+=ddd;//=ddd;
		}//end of for for(y=yf;y<yc;y++)
		//===============================

	}//end of  for ( i=0; i<256; i++ )
}//end of function  Line(x0, y0, x1, y1, hy,s)

void View( int x0p, int y0p, int aap) {

	int d/*, h*/;
	//h=((h0<<8)+b*(h2-h0))>>16;
	// Draw the landscape from near to far without overdraw
	int a_F=aap-FOV;
	if(a_F<0)a_F+=360;
	//if(a_F>360)a_F-=360;
	int aF=aap+FOV;
	//if(aF<0)aF+=360;
	if(aF>360)aF-=360;

	int cosa_F=Cos_LUT[(a_F)]/*65536*/;
	int sina_F=Sin_LUT[(a_F)];

	int cosaF=Cos_LUT[(aF)];
	int sinaF=Sin_LUT[(aF)];
	//memset(tBuffer, 0, 196608/*resX * resY * sizeof(int)*/);
	//memset(columcnt, 0, 256/*1024*/);//sizeof(int)=4;memset(columcnt, 0, 256* sizeof(int)/*resX * resY * sizeof(int)*/);
	for(d=49152;d--;)
	{
		tBuffer[d]=0;//memset(tBuffer, 0, 196608);
	}
	for(d=256;d--;)
	{
		columcnt[d]=0;//memset(columcnt, 0, 1024);//sizeof(int)=4;
	}

	for (d=0; d<100; d+=1+(d>>6)) {
		float dMcosa_F=d*cosa_F;
		float dMsina_F=d*sina_F;
		Line(x0p+dMcosa_F,y0p+dMsina_F, d*cosaF-dMcosa_F,d*sinaF-dMsina_F,//x0p+d*cosaF,y0p+d*sinaF,//
			/*x0p+d*cosa_F,y0p+d*sina_F,     
			x0p+d*cosaF,y0p+d*sinaF,*/
			d/*h-30*//*100*256/(d+1)*/,project_s_t[d]/*screenAt/d*/,project_is_t[d]);
	}//end of for ( d=0; d<100; d+=1+(d>>6) )

}//end of void View