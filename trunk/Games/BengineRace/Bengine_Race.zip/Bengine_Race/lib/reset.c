//���ظ�flash��ǰ����

AS3_Val getset( void* self, AS3_Val args){
	AS3_Val cset;
	AS3_Release(cset);
	cset=AS3_Array("IntType, IntType, IntType, IntType, IntType, IntType, IntType",L(cx0>>16),L(cy0>>16),aa,cheight,MidOut,brush_color,brush_scale);
	return cset;
}//end of getset
//�������ò���
AS3_Val reset( void* self, AS3_Val args){
	//screenAt=1/tan(3.14159265358979/4)*160;//FOV
	AS3_ArrayValue(args,
		"IntType,IntType,IntType,IntType,IntType,IntType,IntType",&cx0,&cy0,&aa,&cheight,&MidOut,&brush_color,&brush_scale);
	cx0=cx0<<16;
	cy0=cy0<<16;
	View(cx0, cy0, aa);
	return 0;
}//end of reset
