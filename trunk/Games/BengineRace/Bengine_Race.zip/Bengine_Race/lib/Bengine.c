#include "AS3.h"
#include <math.h>

#include "def_var.c"
#include "loader.c"
#include "ray_caster.c"

#include "editor/destroy.c"

//#include "reset.c"
#include "physics/physics.c"
AS3_Val AS_Main;
#include "ALC_GE2D_PlaySound.c"

#include "game/game.c"

int K_LEFT=0;
int K_RIGHT=0;
int K_UP=0;
int K_DOWN=0;
int K_q=0;
int K_e=0;
int K_z=0;
int K_x=0;
int K_c=0;
int K_space=0;



AS3_Val initialize(void* self, AS3_Val args)
{
	AS3_ArrayValue(args,"AS3ValType",&AS_Main);
	screenAt=/*1/tan(3.14159265358979/4)*160;*/160;
	//cheight=96;
	//MidOut=128;
	Build_sct_table();
	init_raytable();

	initGame();

	AS3_ArrayValue(args,"IntType,IntType",&resX,&resY);//?

	tBuffer = malloc( resX * resY * sizeof(int) );
	return AS3_Ptr( tBuffer );
}

AS3_Val loop( void* self, AS3_Val args)
{
	do_gravity();
	loopGame();
	int sa=0;
	int ss=0;
	AS3_ArrayValue(args,
		"IntType, IntType, IntType, IntType, IntType, IntType, IntType, IntType, IntType, IntType", 
		&K_UP, &K_DOWN, &K_RIGHT, &K_LEFT, &K_q, &K_e, &K_z, &K_x, &K_c, &K_space);

	if (K_UP) {
		if(speed==1)
		{ss += 40960;}
		else{//(speed==2)
			ss += 81920;//40960*2;//40960*speed;
			//AS3_CallTS("playsound", AS_Main, "StrType",("Race"));
			Tspeed--;//=(speed-1);
		}

	}
	else if (K_DOWN) {
		ss -= 20480;//40960;
		if(Tspeed<50)
		{Tspeed++;}
		//AS3_CallTS("playsound", AS_Main, "StrType",("Stop"));
	}

	if (K_RIGHT && sa > -30 ) {
		sa -= 6;//10;//0.5;
	}
	else if(K_LEFT && (sa < 30)) {
		sa += 6;//10;//0.5;
		//printf("%d\n",sa);
	}

	// Update position/angle
	if (K_q && MidOut>96) {
		MidOut-=2;
	}
	else if (K_e && MidOut<160/*16096*/) {
		MidOut+=2;
	}


	if (K_z) {
		if(Tspeed>0)
		{speed=2;
		//Status=0;
		}
		armor=0;
		power=0;
		//AS3_CallTS("playsound", AS_Main, "StrType",("ChangForm"));
	}
	else if (K_x) {
		speed=1;
		if(Tarmor>0)
		{armor=1;
		//Status=1;
		}
		power=0;
		//AS3_CallTS("playsound", AS_Main, "StrType",("ChangForm"));
	}
	else if (K_c) {
		speed=1;
		armor=0;
		if(Tpower>0)
		{power=1;
		//Status=2;
		}
		//AS3_CallTS("playsound", AS_Main, "StrType",("ChangForm"));
	}


	if (K_space) {
		if(power>0)
		{
			cheight+=2;//2*power;
			if(check_hit_ceil())
			{
				cheight--;//=2*power-1;
				//AS3_CallTS("playsound", AS_Main, "StrType",("Fly"));
			}
			Tpower--;//=power;
			if(Tarmor<50)Tarmor+=2;
		}//end of if(power>0)
		//
	}

	//else {return 0;}
	aa += sa;
	if(aa<0)aa+=360;
	else if(aa>359)aa-=360;
	float vx = Cos_LUT[aa]/65536;
	float vy = Sin_LUT[aa]/65536;
	//printf("%f\n",vx);
	//printf("%i\n",aa);
	//printf("%f\n",vy);
	if(K_UP||K_DOWN)
	{
		cx0 += ss * vx;
		cy0 += ss * vy;
		//global
		gu0=L((cx0>>16));
		gv0=L((cy0>>16));
		guv=gu0<<8|gv0;
		//global
		if(check_hit_move())
		{   
			if(armor==0)
			{
				cx0 -= ss * vx;
				cy0 -= ss * vy;
				//global
				gu0=L((cx0>>16));
				gv0=L((cy0>>16));
				guv=gu0<<8|gv0;
				//global
				MyLife-=10;
				if(Tpower<40)Tpower+=10;
				AS3_CallTS("playsound", AS_Main, "StrType",("Hit"));
			}
			else if(cx0>(5<<16))
			{
				Tarmor--;
				destroy();AS3_CallTS("playsound", AS_Main, "StrType",("Explosion"));
			}
			else
			{
				cx0 -= ss * vx;
				cy0 -= ss * vy;
				//global
				gu0=L((cx0>>16));
				gv0=L((cy0>>16));
				guv=gu0<<8|gv0;
				//global
			}
		}
	}//end of if(K_UP||K_DOWN)

	View(cx0, cy0, aa);

	AS3_Val pos = AS3_Array("IntType, IntType,IntType,IntType,IntType,IntType",MyLife,Tspeed,Tarmor,Tpower,(L(cx0>>16)>>1)+4,(L(cy0>>16)>>2)+4);

	return pos;//0
}//end of AS3_Val loop



int main()
{

	AS3_Val initializeMethod = AS3_Function( NULL, initialize);

	AS3_Val loadvoxdataMethod = AS3_Function( NULL, loadvoxdata);
	AS3_Val ComputeMapMethod = AS3_Function( NULL, ComputeMap);
	AS3_Val loopMethod = AS3_Function( NULL, loop);

	AS3_Val newGameMethod = AS3_Function( NULL, newGame);
	AS3_Val calculateRemainMethod = AS3_Function( NULL, calculateRemain);
	//AS3_Val getsetMethod = AS3_Function( NULL, getset);
	//AS3_Val resetMethod = AS3_Function( NULL, reset);


	AS3_Val result = AS3_Object("initialize:AS3ValType,loadvoxdata:AS3ValType,ComputeMap:AS3ValType,loop:AS3ValType,newGame:AS3ValType,calculateRemain:AS3ValType"/*,getset:AS3ValType,reset:AS3ValType*/,
		initializeMethod, loadvoxdataMethod, ComputeMapMethod, loopMethod, newGameMethod,calculateRemainMethod/*, getsetMethod, resetMethod*/);// 

	AS3_Release( calculateRemainMethod );
	AS3_Release( newGameMethod );

	AS3_Release( initializeMethod );
	AS3_Release( loadvoxdataMethod );
	AS3_Release( ComputeMapMethod );
	AS3_Release( loopMethod );
	//AS3_Release( getsetMethod );
	//AS3_Release( resetMethod );

	AS3_LibInit( result );
	return 0;
}//end of int main