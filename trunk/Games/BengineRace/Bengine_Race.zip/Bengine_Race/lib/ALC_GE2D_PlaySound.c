//int (*PlaySound)(const char *name, int times) = AS3_Shim("PlaySound", AS_Main, "IntType, StrType, IntType", 0,0);AS3_Proxy?
void PlaySound(char* name, int times)
{
	//AS3_Trace(AS3_String("PlaySound"));
	AS3_CallTS("PlaySound", AS_Main, "StrType,IntType",name,times);
}//end of initialize
//multi-byte strings require double quotes
