
namespace Wolf5K
{
  int bm[1024]={
    65535,128,448,128,65535,14336,4096,14336,65535,14,4,14,65535,448,128,448, //wall
    65535,53259,40965,49155,32865,32913,37505,35457,34417,35345,37617,33281,49667,40965,53259,65535, //5K wall tile
    2040,1224,720,7928,4740,32740,65508,1088,1008,1032,2244,2340,2052,2340,1032,1008, //enemy
    8184,4104,12680,12680,6120,6120,4488,4488,4104,8184,0,0,0,0,0,0, //health
    8184,8184,8184,8184,8184,8184,8184,8184,8184,8184,0,0,0,0,0,0, //health mask
    2040,2040,0x3f0,8184,8188,32764,65532,18424,1008,2040,4092,4092,4092,4092,2040,1008, //enemy mask
    5136,5136,2592,2592,1088,1984,0,0,0,0,0,0,0,0,0,0,//gun
    8176,8176,4064,4064,1984,1984,0,0,0,0,0,0,0,0,0,0,//gun mask
    1008,1032,2340,2052,2340,2244,1032,1008,0,0,0,0,0,0,0,0, //dead enemy
    1008,2040,4092,4092,4092,4092,2040,1008,0,0,0,0,0,0,0,0,	//dead enemy mask
    0,0,0,0,0,2080,6096,9544,2336,256,0,0,0,0,0,0 //gunfire
  };

  //FontMap is our "font" encoded in bits
  //see the A6, A7 functions for why the bits
  //are "backwards."  This is inconsistant with
  //the bm array since the bits are not reversed
  //just the image is flipped vertically
  int FontMap[50]={
    7,5,5,5,7, //0
    1,3,1,1,1, //1
    7,1,7,4,7, //2
    7,1,7,1,7, //3
    5,5,7,1,1, //4
    7,4,7,1,7, //5
    7,4,7,5,7, //6
    7,1,1,1,1, //7
    7,5,7,5,7, //8
    7,5,7,1,1  //9
  };
};

class cNode
{
 public:
  cNode * next;
  double x,y,d,l,a,r;
  double dx,dy;
  int i,c,z;

  cNode()
    {
      x=y=d=l=a=r=dx=dy = 0;
      i=c=z=0;
      next = 0;
    }

  cNode(cNode &node)
    {
      x=node.x;
      y=node.y;
      z=node.z;
      d=node.d;
      l=node.l;
      a=node.a;
      r=node.r;
      dx=node.dx;
      dy=node.dy;
      i=node.i;
      c=node.c;

      next = 0;
    }

  cNode(cNode * node)
    {
      x=node->x;
      y=node->y;
      z=node->z;
      d=node->d;
      l=node->l;
      a=node->a;
      r=node->r;
      dx=node->dx;
      dy=node->dy;
      i=node->i;
      c=node->c;

      next = 0;
    }

};

class cNodeHandler
{
 public:
  cNode * head;
  cNode * tail;
  int count;

  cNodeHandler()
    {
      head = 0;
      tail = 0;
      count = 0;
    }

  void clear()
  {
    if(head!=0)
      {
	cNode * current=head;
	while(current!=0)
	  {
	    current=current->next;
	    delete head;
	    head = current;
	  }
	head = 0;
	tail = 0;
      }
  }

  ~cNodeHandler()
    {
      clear();
    }

  void addNode(cNode &node)
  {
    if(head==0)
      {
	head = new cNode(node);
	tail = head;
      }
    else
      {
	tail->next = new cNode(node);
	tail=tail->next;
      }
    count++;
  }

  void toString()
  {
    cNode * current = head;
    while(current!=0)
      {
	printf("%i:\t%i\n",current,current->x);
	current=current->next;
      }
  }

  void Sort()
  {
    head = MergeSort_Lin(head);
    cNode * current = head;
    while(current->next!=0)
      current=current->next;
    tail = current;
  }

  // http://www.chiark.greenend.org.uk/~sgtatham/algorithms/listsort.html
  /*
   * This [method] is copyright 2001 Simon Tatham.
   *
   * Permission is hereby granted, free of charge, to any person
   * obtaining a copy of this software and associated documentation
   * files (the "Software"), to deal in the Software without
   * restriction, including without limitation the rights to use,
   * copy, modify, merge, publish, distribute, sublicense, and/or
   * sell copies of the Software, and to permit persons to whom the
   * Software is furnished to do so, subject to the following
   * conditions:
   *
   * The above copyright notice and this permission notice shall be
   * included in all copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
   * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
   * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
   * NONINFRINGEMENT.  IN NO EVENT SHALL SIMON TATHAM BE LIABLE FOR
   * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
   * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
   * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   */
  cNode * MergeSort_Lin(cNode * list)
  {
    cNode *p, *q, *e, *tail;
    int insize, nmerges, psize, qsize, i;

    if (!list)
      return 0;

    insize = 1;

    while (1)
      {
	p = list;
	list = 0;
	tail = 0;

	nmerges = 0;  /* count number of merges we do in this pass */

	while (p)
	  {
	    nmerges++;  /* there exists a merge to be done */
	    /* step `insize' places along from p */
	    q = p;
	    psize = 0;
	    for (i = 0; i < insize; i++)
	      {
		psize++;
		q = q->next;

		if (!q)
		  break;
	      }

	    /* if q hasn't fallen off end, we have two lists to merge */
	    qsize = insize;

	    /* now we have two lists; merge them */
	    while (psize > 0 || (qsize > 0 && q))
	      {
		/* decide whether next element of merge comes from p or q */
		if (psize == 0)
		  {
		    /* p is empty; e must come from q. */
		    e = q;
		    q = q->next;
		    qsize--;
		  }
		else
		  if (qsize == 0 || !q)
		    {
		      /* q is empty; e must come from p. */
		      e = p;
		      p = p->next;
		      psize--;
		    }
		  else
		    if (p->d > q->d)
		      {
			/* First element of p is lower (or same);
			 * e must come from p. */
			e = p;
			p = p->next;
			psize--;
		      }
		    else
		      {
			/* First element of q is lower; e must come from q. */
			e = q;
			q = q->next;
			qsize--;
		      }

		/* add the next element to the merged list */
		if (tail)
		  tail->next = e;
		else
		  list = e;
		tail = e;
	      }

	    /* now p has stepped `insize' places along, and q has too */
	    p = q;
	  }
	tail->next = 0;

	/* If we have done only one merge, we're finished. */
	if (nmerges <= 1)   /* allow for nmerges==0, the empty list case */
	  return list;

	/* Otherwise repeat, merging lists twice the size */
	insize *= 2;
      }
  }
};

class cWolf5K
{
 private:
  double C,F,R,b2,c3,c4,INF,RAD,playerRotation;
  double DistToProjPlane;
  int hasShot,frameDelay,U,frameNumber,im,/*gameLevel,playerPoints,*/Z/*,numMonsters,playerDead,numKilled*/;
  int M,/*playerHealth,*/playerEyeLevel,cz;
  double playerX,playerY;

  int H,W; //screen resolution
  double * zBuffer;
  int * BlankScreen;
  int * w;

  cNodeHandler objects;
  FILE * logfile;

 public:
  int * p; //video memory
  int gameLevel,playerPoints,numMonsters,playerDead,numKilled,playerHealth;
  int ShowMap;//?
  cWolf5K()
    {
    }

  void Init(int sw, int sh)
  {
    H=sh;
    W=sw;

    zBuffer = new double[W];
    BlankScreen = new int[W*H];
    w = new int[64];
    p = new int[W*H];


    cz=0;
    C=3.14159265;
    hasShot=frameDelay=U=frameNumber=im=gameLevel=playerPoints=Z=numMonsters=playerDead=numKilled=0;  //gameLevel = level number
    M=playerHealth=64;
    playerRotation = 0.0;
    playerX=playerY=128;
    RAD=C/180.0; 	//used to convert angles to radians
    playerEyeLevel=H/2;
    INF=10e30;			//infinity
    F=30.0f*RAD;			//angle of view (larger distorts the "lens")
    R=2.0*F/(double)W;			//this is the angle of each ray to cover 128 pixels
    DistToProjPlane=floor(((double)W/2.0)/tan(F));	//110 pixels
    b2=C/2.0;				//90 degrees
    c3=C;				//180 degrees
    c4=C*3.0/2.0; 			//270 degrees

    for(int i=0;i<H*W;i++)
      {
	if(i>=(H-16)*W)
	  BlankScreen[i]=200;//1;
	else
	  BlankScreen[i]=0;
      }

    //logfile = fopen("wolf5k.log","w");
  }

  ~cWolf5K()
    {
      delete zBuffer;
      delete BlankScreen;
      delete w;
      delete p;

      //fclose(logfile);
    }

  void Move(int d)
  {
    double fwd = 12.0f;//15.0f;
    if(d=='L') //if we are rotating adjust the rotation angle
      playerRotation-=3.0*RAD;//5.0*RAD;  //playerRotation is the players view angle
    if(d=='R') //if we are rotating adjust the rotation angle
      playerRotation+=3.0*RAD;//5.0*RAD;  //playerRotation is the players view angle

    if(d=='U') //if we are moving forward
      {
	//store the new coordinates in temporary variables
	double c8=playerX+fwd*cos(playerRotation);
	double c9=playerY+fwd*sin(playerRotation);

	if(!IsNotValidLocation(c8,c9)) //if we have not collided with anything
	  {
	    playerX=c8; //set the players location to the new location
	    playerY=c9;
	  }
      }

    if(d=='D') //if we are moving backwards
      {
	//store the new coordinates in temporary variables
	double c8=playerX-fwd*cos(playerRotation);
	double c9=playerY-fwd*sin(playerRotation);

	if(!IsNotValidLocation(c8,c9)) //if we have not collided with anything
	  {
	    playerX=c8; //set the players location to the new location
	    playerY=c9;
	  }
      }

    if(d=='Q') //if we are moving forward
      {
	//store the new coordinates in temporary variables
	double c8=playerX+fwd*sin(playerRotation);
	double c9=playerY-fwd*cos(playerRotation);

	if(!IsNotValidLocation(c8,c9)) //if we have not collided with anything
	  {
	    playerX=c8; //set the players location to the new location
	    playerY=c9;
	  }
      }

    if(d=='E') //if we are moving forward
      {
	//store the new coordinates in temporary variables
	double c8=playerX-fwd*sin(playerRotation);
	double c9=playerY+fwd*cos(playerRotation);

	if(!IsNotValidLocation(c8,c9)) //if we have not collided with anything
	  {
	    playerX=c8; //set the players location to the new location
	    playerY=c9;
	  }
      }

    if(d==' ') //if we are shooting
      {
	if(!playerDead && !frameDelay && hasShot<-2)
	  {
	    cNode * o = objects.head;
	    hasShot = 2;
	    PlaySound("heroshoot",1);
	    while(o!=0)
	      {
		if(o->i && !o->z && o->l<W/2 && o->r>W/2 && o->c==1)
		  {
		    o->z=1;
		    numKilled++;	//numKilled is the kill count
		    playerPoints+=10*(gameLevel+o->d/64);
		    PlaySound("enemydead",1);
		  }
		o=o->next;
	      }
	  }

	//check to see if we've beaten the level
	if(numMonsters-numKilled<2) //numMosters is 1 greater than there actually are
	  //so if 1 is left then there are zero left
	  {
	    Start();				//start a new level
	  }
      }
  }
  //this is the function to plot a pixel at x,y with color v
  inline void PlotPixel(int x, int y, int v)
  {
    p[y*W+x]=v*200;
  }

  //this returns the maps wall value at x,y
  //a one indicates we hit a wall
  inline int IsNotValidLocation(double x,double y)
  {
    x=floor(x/64);//we divide by 64 to figure out which tile of the map we are on
    y=floor(y/64);

    //if we are out of bounds return one, otherwise return the value of the wall
    //we are storing the map in bits so we do the &2^x trick to get the bit of the wall
    //array value
    return(x<0||y<0||x>15||y>15)?1:(w[(int)y]&1<<(int)x);
  }

  void Start()
  {
    //this function generates the initial screen and initializes
    //the map and object locations

    frameDelay=36;  				// we want to wait 36 frame delays before the game actually starts
    gameLevel++;					// increment the level number
    playerX=playerY=128;						// initial player location
    numKilled=numMonsters=0;
    playerHealth=64;
    playerRotation=0.0;
    memcpy(p,BlankScreen,H*W*sizeof(int));	// store the blank screen in the "video memory"
    DrawNumber(gameLevel,W/2-2,H/2,0); 	// draw the level number on the screen
    cz=0;
    //ZeroMemory(w,64);			// w is the world map,
    memset(w,0,64*sizeof(int));
    int d1=30+4*gameLevel; 				// d1 is the number of wall cubes that will be put in the map
    int x,y,j,k;						// we do not care if they are all in unique locations
    while(d1)
      {
	x=rand()%16;
	y=rand()%16;
	if(x*y>4)
	  {
	    w[y]=w[y]|1<<x;				//w is an array of bits and we have a 16x16 map
	    d1--;
	  }
      }

    cNode object;
    objects.clear();
    d1=6+4*gameLevel; 		 			//i is the number of objects
    while(d1)
      {
	x=64*((rand()%12)+2); //random location for object
	y=64*((rand()%12)+2);
	j=d1%8?1:0; 								//one in every eight objects is a health kit
	if(!IsNotValidLocation(x,y)) 			//make sure the location is valid
	  {
	    object.x=x;
	    object.y=y;
	    object.i=j; 													//i is the object type.  1 == monster 0 == health
	    k=(rand()%1000)/1000.0f>.5?1:-1; //random starting movement
	    object.dx=j?(rand()%48)/4*gameLevel*k:0; //j?(rand()%64)/4*gameLevel*k:0; 	//no special handling for health
	    object.dy=j?(rand()%48)/4*gameLevel*k:0;//j?(rand()%64)/4*gameLevel*k:0; 	//just set its movement to zero
	    object.z=0; 													//we are not dead yet
	    object.c=0; 													//meaningless default value
	    objects.addNode(object);
	    d1--; 										//we have i-1 to go
	    numMonsters+=j;								//number of enemies, only add one if not health
	  }
      }
  }

  //number rendering function
  //$a is the number
  //$m is the x coordinate to draw at
  //$k is the y coordinate to draw at
  //r determines whether to invert the colors
  // of the number
  void DrawNumber(int a, int m, int k, int r) //A6()
  {
    //if the number is less than 1 then just draw 0
    if(a<1)
      DrawDigit(0,m,k,r);
    else
      {
	//this formula returns the approx number of digits in the number
	//if a is 898 then log(a)/log(10) (where log is the natural log)
	//is equal to ~2.9 with the floor puts it at 2. 10^2 is 100.
	//898/100 is 8.98 and the floor reduces it to 8 which is the
	//value of the digit we were looking for.  We then subtract
	//800 from the original value and go to the next digit
	int t,j;
	for(int i=(int)floor(log((double)a)/log(10.0));i>=0;i--,m+=4)
	  {
	    t=(int)pow(10,i);
	    j=(int)floor((double)a/(double)t);
	    DrawDigit(j,m,k,r);
	    a-=j*t;
	  }
      }
  }

  //this function draws individual digits
  void DrawDigit(int a,int m,int pk,int r) //A7()
  {
    int d;
    for(int k=0;k<5;k++)//there are five rows of pixels per number
      {
	d=Wolf5K::FontMap[a*5+k]; //get the numeric value for the row of pixels

	if(r)//if r is non zero then invert the color of the pixels
	  d=7-d;

	//each row has three pixels.
	//&4 is the first pixel
	//&2 is the second pixel
	//&1 is the third pixel
	//apparently this guy is used to working with big endien systems.
	//"normally" binary is 1 2 4 8 16 32 ... etc
	//this is working with etc ... 32 16 8 4 2 1
	PlotPixel(m+1,pk+k,(d&4)/4);
	PlotPixel(m+2,pk+k,(d&2)/2);
	PlotPixel(m+3,pk+k,d&1);
      }
  }

  //this is the function which renders the sprite
  //tile is the sprite number, mask is the mask number
  //r determins if we are inverting the colors
  //$f tells the function if this is a sprite or or wall
  int DrawSprite(int tile,int mask,double sy,double sx,double dy,double dx,double f,int r)
  {
    double ht=fabs(dy-sy);
    double wd=fabs(dx-sx);
    int g=0;
    int pY;
    int pX;
    int clr;
    int msk;

    if(sy<0)
      sy=0.0f;
    if(dy>=H)
      dy=H-1.0f;

    for(int k=sx;k<dx;k++) // drawing from left to right
      {
	//if f is zero then we draw as long as it is on the screen
	//otherwise check zBuffer which holds scanline information
	//for visibility, if something already occupies the at
	//a closer depth then we know that whatever we were
	// attempting to draw
	//is hidden so we do not draw it
	if(k>=0&&k<=W&&!(f&&(f>zBuffer[k])))
	  {
	    //what pixel in the sprite we are looking at
	    pX=((int)((k-sx)/wd*16))&15;

	    for(int j=sy;j<dy;j++) // and then top to bottom
	      {
		// the y line of the sprite
		pY=15-((j-sy)/ht*16);

		//actual color
		clr=Wolf5K::bm[tile*16+pY]&1<<pX;

		//value of the mask
		msk=Wolf5K::bm[mask*16+pY]&1<<pX;

		//if the mask is non zero plot the
		//actual color (black is 1 in the bm)
		if(msk)
		  {
		    PlotPixel(k,j,clr?!r:r);
		    g=1;
		  }
	      }
	  }
      }
    return g;
  }

  void UpdateObjects()
  {
    double tx=cos(playerRotation);
    double ty=sin(playerRotation);

    cNode * o = objects.head;
    while(o != 0)
      {
	if(!o->z)
	  {
	    if(o->c<3) //if the object is not out of view of the player for 3 frames
	      {		  //then move the monster otherwise it can stay hiding
		if(IsNotValidLocation(o->x+o->dx,o->y+o->dy))
		  {	//if the enemy hit a wall then reverse its direction
		    //of travel.
		    o->dx=-o->dx;
		    o->dy=-o->dy;
		  }
		//move the enemy
		o->x+=o->dx;
		o->y+=o->dy;
	      }

	    if(!o->i&&fabs(o->x-playerX)<64&&fabs(o->y-playerY)<64)
	      {//player ran into a health.  Make it go away and reward the player
		//set cz to 1 so that we do not display the flash of red
		o->z=1;
		playerHealth+=(64-playerHealth)/4;
		cz=1;
		PlaySound("pickhealth",1);
	      }
	  }

	if(o->i && !playerDead && o->c==1 && !o->z && (rand()%1000)/1000.0<.05)
	  {//player hit
	    PlaySound("enemyshoot",1);
				
	    playerHealth-=rand()%5; //reduce health 0-7 random %8
			
	    PlaySound("herohit",1);
	    frameDelay=4;
	    cz=2;
	    if(playerHealth<0) //if health is less than zero
	      {
		playerDead=1; //player is dead
		PlaySound("herodie",1);
		playerEyeLevel=H/8; //set the camera Y to 64/8 (fall down)
	      }
	    //				fprintf(logfile,"frameDelay at hit %i\n",frameDelay);
	  }

	double x=o->x-playerX;
	double y=o->y-playerY;
	o->d=sqrt(x*x+y*y);//distance to object
	o->a=acos((tx*x+ty*y)/(o->d)); //angle of line between the two
	if(tx*y-ty*x<0) //if the translated/rotated x distance is less than 0
	  o->a=-o->a;

	o=o->next;
      }
    //		fprintf(logfile,"frameDelay at end of objects %i\n",frameDelay);
  }

  void RenderStatus()
  {
    //this is our status information
    DrawNumber(playerPoints,2,H+1-16,1); //points
    DrawNumber(numMonsters-numKilled-1,26,H+1-16,1); //number of enemies left
    if(!playerDead)//if we're not dead then draw the gun
      {
	hasShot--;
	DrawSprite(6,7,H-32-16,W/2-16,H-16,W/2+16,0,1);
	if(hasShot>0)
	  DrawSprite(10,10,H-32-16,W/2-16,H-16,W/2+16,0,0);
      }
    for(int i=0;i<playerHealth;i++)//draw our health bar
      PlotPixel(W-2-i,H+3-16,0);
  }

  void RenderObjects()
  {
    //sort the array of objects
    objects.Sort();
    cNode * o = objects.head;

    while(o!=0)
      {
	int ht=64/o->d*DistToProjPlane;
	int k=playerEyeLevel-ht/2;
	int l=playerEyeLevel+ht/2;

	int pat=o->i?2:3; //if i is zero then it is a monster, otherwise it is health
	int a9=o->i?5:4;  //get the mask, for no particular reason this is flipped

	o->l=W/2+o->a/R-ht/2;
	o->r=o->l+ht;
	//			fprintf(logfile,"object %i: l %f, r %f, z %f\n",o,o->l,o->r,o->z);
	if(o->z) //o.z determines if the object is dead
	  {
	    //				fprintf(logfile,"object %i: dead\n",o);
	    if(o->i)//if this is a monster
	      {
		pat=8; //set it to a dead monster sprite
		a9=9;
	      }
	    else // there is no dead sprite for anything else
	      {
		o=o->next;
		continue;
	      }
	  }
	//			fprintf(logfile,"object %i: d %f\n",o,o->d);
	if(o->d>64.0f && DrawSprite(pat,a9,k,o->l,l,o->r,o->d,1))
	  {
	    o->c=1; //o.c 1 indicates the monster is visible
	    //				fprintf(logfile,"drawsprite: pat %i\n",pat);
	  }
	else
	  o->c++; //otherwise count frames monster not visible to player

	o=o->next;
      }
    //		fflush(logfile);
  }

  //this is the actual raycasting function which renders
  //the screen.
  void RayCast()
  {
    //store the default background in the video memory
    memcpy(p,BlankScreen,H*W*sizeof(int));

    double c2=-F; //F is the view angle, the larger F is the more we cram into the view area
    double a=playerRotation+c2;  //angle of the ray we are calculating
    double a6=-1;
    double d;
    double Lht;
    double c1;
    double u;
    int uh,uv;
    double a5=INF;
    double a4,f=0.0f,dx,dy,a2,b,q,r,o,p,ht=0.0f;

    for(int v=0;v<W;v++) //what scanline we are working on (0-128)
      {
	c1=f;
	Lht=ht;
	double c=cos(a);
	double s=sin(a);
	double t=s/c;


	if(!a||a==c3) //if a is 0 or 180 then we get a divide by zero error so we ignore the ray
	  {
	    a4=INF;
	  }
	else
	  {
	    if(s>0) //if we are in the top two quadrants
	      {
		b=floor((double)playerY/64.0f+1.0f)*64; //start at the tile in front of the player
		dy=64;							//increment in whole tiles forward
		a2=(double)playerX+(b-(double)playerY)/t;		//start with an adjustment to the side of the player
		dx=64/t;						//increment 64/t to the side (plot chart)
	      }
	    else	//otherwise we are facing backwards so we go in the opposite direction
	      {
		b=floor((double)playerY/64.0f)*64-.0001;
		dy=-64;
		a2=(double)playerX+(b-(double)playerY)/t;
		dx=-64/t;
	      }
	    //while we have not hit a wall tile or edge of the map
	    while(!IsNotValidLocation(a2,b))
	      {
		a2+=dx;	//keep shooting the ray
		b+=dy;
	      }
	    q=a2;	//store the final location where the ray hits a wall tile
	    r=b;
	    a4=abs(((double)playerX-a2)/c);
	    uh=(int)a2%64;	//the pattern repeats every 64 pixels.

	    if(s>0)
	      uh=64-uh;	//flip the pattern
	  }
	if(a==b2||a==c4)  //if we are at 90 or 270 degrees our ray has infinite problems
	  {
	    a5=INF;
	  }
	else
	  {
	    if(c>0)
	      {
		a2=floor((double)playerX/64.0f+1.0f)*64;	//start one tile in front of player
		dx=64;
		b=(double)playerY+(a2-(double)playerX)*t;
		dy=64*t;
	      }
	    else
	      {
		a2=floor((double)playerX/64.0f)*64.0f-.0001; //start just behind player
		dx=-64;
		b=(double)playerY+(a2-(double)playerX)*t;		//at 90 and 270, t goes to infinity so multiplying
		//results in an invalid number
		dy=-64*t;
	      }

	    //again look for the first wall tile we hit
	    while(!IsNotValidLocation(a2,b))
	      {
		a2+=dx;
		b+=dy;
	      }

	    s=a2;
	    t=b;
	    a5=abs(((double)playerX-a2)/c);
	    uv=(int)b%64;
	    if(c<0)
	      uv=64-uv;
	  }

	d=a6;
	//we are looking for the smallest distance to travel
	//both rays cannot be infinite at once so we pick the one
	//that is not infinite
	if(a4<a5)
	  {
	    u=uh; //texture scanline
	    f=a4; //distance from camera
	    a6=0;
	    o=q;	//map x position
	    p=r;	//map y position
	  }
	else
	  {
	    u=uv;	//text scanline
	    f=a5;	//distance from camera
	    a6=1;
	    o=s;	//map x position
	    p=t;	//map y position
	  }

	f*=cos(c2);
	zBuffer[v]=f;	//zBuffer is our z-buffer, $f is the depth of the scanline
	ht=floor(64/f*DistToProjPlane); //height of the scanline
	double dd=abs(c1-f);	//change in distance from previous $f
	int k=(int)floor(playerEyeLevel-ht/2.0);	//the top of our scanline
	int l=(int)floor(playerEyeLevel+ht/2.0); //the bottom of the scanline
	int b3=k;	//starting position for scanning

			//a0 is the x pixel position in the texture
			//u will go from 0 to 63 so dividing by 4 gets us 0 to 15
	int a0=(int)(u/4.0);

	if(dd > 64 && Lht > ht)  //Lht is the previous scanline height
	  ht=Lht;

	if(k<0)	//make sure we are not trying to draw above the view area
	  k=0;

	if(l>=H) //if $l is greater than the height of the view area then adjust
	  l=H-1;

	int x=(int)floor(o/64); //our tile position
	int y=(int)floor(p/64);

	//if we're out of bounds of the map
	//and the level is less than 5 then
	//alternate wall tiles
	//otherwise use the enemy sprite as a wall
	//tile and alternate it.
	//if we're in bounds then use the default
	//wall tile 0
	int pat=(x<0||x>15)&&y%2?1:gameLevel>4?2:0;

	//start at the top of the scanline and work down
	for(y=k;y<l;y++)
	  {
	    //var bit=0; //not actually used for anything.

	    //the row of pixels is based on the current y
	    //y position. >>2 divides by 4.  64/4==16
	    int b1=(int)((y-b3)/ht*64)>>2;


	    //we're subtracting from 15 because the tiles
	    //are stored upside down
	    int b2=Wolf5K::bm[pat*16+(15-b1)]&1<<(a0&15);

	    if(
	       !(
		 b2 ||	// is the color 1 or 0?
		 (v && d != a6) ||	//is $v 0 and $d not equal to a6 ($d is the prior version of a6)
		 (dd >= 64 && v) ||	//if our change in distance is greater than 64 and $v is non 0
		 (f >= 64*3 && f<64*4 && v%4==y%4) ||	//skip pixels based on distance from player
		 (f >= 64*4 && f<64*6 && v%3==y%3) || //this is how the "lighting" is done
		 (f >= 64*6 && v%2==y%2)
		 )
	       )
	      PlotPixel(v,y,1); //if after all of the checks we having something to plot
	  }

	a+=R;	//increment the ray angle
	c2+=R;	//
      }
  }

  void RenderBlood()
  {
    //store the default background in the video memory
    memcpy(p,BlankScreen,H*W*sizeof(int));
    int x,y;
    for(x=0;x<W;x++)
      for(y=0;y<H;y++)
	p[y*W+x]=0xff0000;//PlotPixel(x,y,1);
  }

  void RenderMap()
  {
    //store the default background in the video memory
    //memcpy(p,BlankScreen,H*W*sizeof(int));
    int x,y;
    cNode * o = objects.head;
    while(o != 0)
      {
	x=floor(o->x/64);
	y=floor(o->y/64);
	if(!o->z)
	  {
	    if(o->i)
	      {
                p[y*W+x]=0xff0000;//PlotPixel(floor(o->x/64),floor(o->y/64),10);
		p[y*W+x+1]=0xff0000;
                p[(y+1)*W+x]=0xff0000;
		p[(y+1)*W+x+1]=0xff0000;
	      }
	    else //if(!o->i)
	      {
                p[y*W+x]=0xffffff;//PlotPixel(floor(o->x/64),floor(o->y/64),10);
		p[y*W+x+1]=0xffffff;
                p[(y+1)*W+x]=0xffffff;
		p[(y+1)*W+x+1]=0xffffff;
	      }
	  }
			
	o=o->next;
      }//end of while
    x=floor(playerX/64);
    y=floor(playerY/64);
    p[y*W+x]=0x00ff00;//PlotPixel(floor(o->x/64),floor(o->y/64),10);
    p[y*W+x+1]=0x00ff00;
    p[(y+1)*W+x]=0x00ff00;
    p[(y+1)*W+x+1]=0x00ff00;
  }

  void main()
  { 
    frameDelay--;
    if(frameDelay<0)
      {
	frameDelay=0;
	cz=0;
	UpdateObjects();
	RayCast(); //render the screen
	RenderObjects();
	RenderStatus();
	if(ShowMap)RenderMap();
      }
    else
      {
	if(cz==2)RenderBlood();
      }//end of else

  }
};
