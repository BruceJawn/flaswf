//Raycasting Engine from Ben Kucenski's Wolf5K Tutorial
//http://code.dawnofthegeeks.com/about/
//http://code.dawnofthegeeks.com/2009/05/05/c-lesson-37-wolf5k-making-it-better-part-1/
//Modified for Alchemy by Bruce Jawn
//http://bruce-lab.blogspot.com
#include "AS3.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include <conio.h>
AS3_Val AS_Main;
#include "ALC_GE2D_PlaySound.c"
#include "wolf5k4.h"
//============================================================
//============================================================
int K_LEFT=0;
int K_RIGHT=0;
int K_UP=0;
int K_DOWN=0;
int K_SPACE=0;
int K_M=0;
int K_Q=0;
int K_E=0;
//============================================================
//============================================================
int screenW,screenH,j;

cWolf5K wolf5k;

void StartUp()
{
  wolf5k.Init(320,240);
  //wolf5k.Init(640,480);
  wolf5k.Start();
}

AS3_Val initializeScreenBuffer(void* self, AS3_Val args)
{
  StartUp();
  AS3_ArrayValue(args,"AS3ValType,IntType,IntType",&AS_Main, &wolf5k.gameLevel, &wolf5k.playerPoints);
  //#include "mochipro.c"
  return AS3_Ptr(wolf5k.p);
}//end of initializeScreenBuffer

//start the main loop
AS3_Val loop( void* self, AS3_Val args )
{
  AS3_ArrayValue(args,"IntType,IntType,IntType,IntType,IntType,IntType,IntType,IntType",
		 &K_UP,&K_DOWN,&K_LEFT,&K_RIGHT,&K_SPACE,&K_M,&K_Q,&K_E);
  wolf5k.main();

  if(K_UP) wolf5k.Move('U');
  if(K_DOWN) wolf5k.Move('D');
  if(K_LEFT) wolf5k.Move('L');
  if(K_RIGHT) wolf5k.Move('R');
  if(K_SPACE) wolf5k.Move(' ');
  if(K_Q) wolf5k.Move('Q');
  if(K_E) wolf5k.Move('E');
  wolf5k.ShowMap=K_M;
  //gameLevel,playerPoints,numMonsters,playerDead,numKilled,playerHealth;
  return AS3_Array("IntType,IntType,IntType,IntType,IntType,IntType",
		   wolf5k.gameLevel,wolf5k.playerPoints,wolf5k.numMonsters,wolf5k.playerDead,wolf5k.numKilled,wolf5k.playerHealth);
}//end of loop
 
int main()
{
  AS3_Val initializeScreenBufferMethod = AS3_Function( NULL,initializeScreenBuffer );
  AS3_Val loopMethod = AS3_Function( NULL,loop );
  AS3_Val result = AS3_Object("initializeScreenBuffer:AS3ValType,loop:AS3ValType"
			      ,initializeScreenBufferMethod,loopMethod);
  AS3_Release( initializeScreenBufferMethod );
  AS3_Release( loopMethod );
  AS3_LibInit( result );
  return 0;
}//end of main
//================================================================
//================================================================
